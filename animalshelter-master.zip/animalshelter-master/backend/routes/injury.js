const express = require('express');
const router = express.Router();
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth')
const {createInjury,
		getInjury,
		findInjury,
		updateInjury,
		deleteInjury
} = require('../controllers/injuryController');

router.route('/injury/new').post(isAuthenticatedUser, authorizeRoles('admin','personnel'),createInjury);
router.route('/injuries').get(isAuthenticatedUser, authorizeRoles('admin','personnel'),getInjury);
router.route('/injury/:id').get(isAuthenticatedUser, authorizeRoles('admin','personnel'),findInjury).put(isAuthenticatedUser, authorizeRoles('admin','personnel'),updateInjury).delete(isAuthenticatedUser, authorizeRoles('admin','personnel'),deleteInjury);
// router.route('/animalUpdate/:id').put(updateAnimal).delete(updateAnimal);
module.exports = router;