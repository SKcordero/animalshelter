const express = require('express');
const router = express.Router();
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth')
const {createAnimal,
		AdoptableAnimals,
		fetchAnimals,
		findAnimal,
		updateAnimal,
		deleteAnimal,
		getAnimBreeds,
		getSickAnimals,
		treatAnimal,
		requestAdoption,
		getAdoptionRequests,
		approveAdoption,
		removeRequest,
		commentAnimal,
		getAdoptedAnimals,
		getRescuedChart,
		getAdoptedChart
} = require('../controllers/animalController');

router.route('/animal/new').post(isAuthenticatedUser, authorizeRoles('admin','personnel'), createAnimal);
router.route('/home').get(AdoptableAnimals);
router.route('/animals').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), fetchAnimals);
router.route('/rescuedChart').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), getRescuedChart);
router.route('/adoptedChart').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), getAdoptedChart);
router.route('/animals/sick').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), getSickAnimals);
router.route('/animals/sick/:id').put(isAuthenticatedUser, authorizeRoles('admin','personnel'), treatAnimal);
router.route('/animals/comment').post(isAuthenticatedUser, commentAnimal);
router.route('/animals/requests').get(isAuthenticatedUser, authorizeRoles('admin','personnel'),getAdoptionRequests);
router.route('/animals/requests/:id').put(isAuthenticatedUser, authorizeRoles('admin','personnel'), approveAdoption);
router.route('/animals/requests/remove/:id').put(isAuthenticatedUser, authorizeRoles('admin','personnel'), removeRequest);
router.route('/request/:id').put(isAuthenticatedUser, requestAdoption);
router.route('/animalBreed').get(getAnimBreeds);
router.route('/me/adopted').get(isAuthenticatedUser, getAdoptedAnimals);
router.route('/animal/:id').get(findAnimal).delete(isAuthenticatedUser, authorizeRoles('admin','personnel'), deleteAnimal);
router.route('/animalUpdate/:id').put(isAuthenticatedUser, authorizeRoles('admin','personnel'), updateAnimal);
module.exports = router;