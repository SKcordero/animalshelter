const express = require('express');
const router = express.Router();
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth')
const { 
	registerUser,
	loginUser,
	logout,
	forgotPassword,
	resetPassword, 
	updatePassword,
	allUsers,
	getUserDetails,
	getUserProfile,
	updateProfile,
	createUser,
	updateUser,
	deleteUser,
	getAdopters,
	changeStatus
} = require('../controllers/authController');

router.route('/register').post(registerUser);
router.route('/user/new').post(isAuthenticatedUser, authorizeRoles('admin','personnel'), createUser);
router.route('/login').post(loginUser);
router.route('/logout').get(logout);
router.route('/password/forgot').post(forgotPassword);
router.route('/password/reset/:token').put(resetPassword);
router.route('/password/update').put(isAuthenticatedUser, updatePassword);

router.route('/admin/adopters').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), getAdopters);
router.route('/admin/adopters/:id').put(isAuthenticatedUser, authorizeRoles('admin','personnel'), changeStatus);
router.route('/admin/users').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), allUsers);
router.route('/admin/user/:id')
    .get(getUserDetails).put(isAuthenticatedUser, authorizeRoles('admin','personnel'), updateUser).delete(isAuthenticatedUser, authorizeRoles('admin','personnel'),deleteUser);
router.route('/me').get(isAuthenticatedUser, getUserProfile);
router.route('/me/update').put(isAuthenticatedUser, updateProfile);

module.exports = router;