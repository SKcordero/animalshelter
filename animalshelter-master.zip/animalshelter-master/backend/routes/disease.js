const express = require('express');
const router = express.Router();
const { isAuthenticatedUser, authorizeRoles } = require('../middlewares/auth')
const {createDisease,
		getDisease,
		findDisease,
		updateDisease,
		deleteDisease
} = require('../controllers/diseaseController');

router.route('/disease/new').post(isAuthenticatedUser, authorizeRoles('admin','personnel'), createDisease);
router.route('/diseases').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), getDisease);
router.route('/disease/:id').get(isAuthenticatedUser, authorizeRoles('admin','personnel'), findDisease).put(isAuthenticatedUser, authorizeRoles('admin','personnel'), updateDisease).delete(isAuthenticatedUser, authorizeRoles('admin','personnel'), deleteDisease);
// router.route('/animalUpdate/:id').put(updateAnimal).delete(updateAnimal);
module.exports = router;