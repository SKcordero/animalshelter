const Injury = require('../models/injury')
const ErrorHandler = require('../utils/errorH');

exports.createInjury = async(req,res,next) => {
	// console.log(req.body);
	// req.body.user = req.user.id;
	const injury = await Injury.create(req.body);
	
	res.status(201).json({
		success:true,
		injury 
	})
}

exports.getInjury = async (req,res,next) => {
	const injuries = await Injury.find();
	// const resPerPage = 4;
	// const productsCount = await Animal.countDocuments();
	// const apiFeatures = new APIFeatures(Animal.find(),req.query).search().filter();
	
	// apiFeatures.pagination(resPerPage);
	// // products = await apiFeatures.query
	// const products = await apiFeatures.query
	// let filteredProductsCount = products.length;

	if(!injuries) {
	return next(new ErrorHandler('my error',400))
	}
	res.status(200).json({
		success: true,
		// count: products.length,
		// productsCount,
 	// 	resPerPage,
 	// 	filteredProductsCount,
 		injuries
		
	})
}

exports.findInjury = async(req,res,next) => {
	 const injury = await Injury.findById(req.params.id);
	 // if(!animal) {
	 // 		return res.status(404).json({
	 // 			success: false,
	 // 			message: 'Animal not found'
	 // 		})
	 // }
	  if(!injury) {
	 		return next(new ErrorHandler('Injury not found',404));
	 }
	 res.status(200).json({
	 	success: true,
	 	injury
	 })
}

exports.updateInjury = async(req,res,next) => {
	let injury = await Injury.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!injury) {
	 		return next(new ErrorHandler('Injury not found',404));
	 }
injury = await Injury.findByIdAndUpdate(req.params.id,req.body,{
	 	new: true,
	 	runValidators:true,
	 	useFindandModify:false
	 })
	 res.status(200).json({
	 	success:true,
	 	injury
	 })
}

exports.deleteInjury = async(req,res,next) =>{
	const injury = await Injury.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!injury) {
	 		return next(new ErrorHandler('Injury not found',404));
	 }
	 await injury.remove();
	 res.status(200).json({
	 	success: true,
	 	message: 'Injury deleted'
	 })
}