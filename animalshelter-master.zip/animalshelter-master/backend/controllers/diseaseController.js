const Disease = require('../models/disease')
const ErrorHandler = require('../utils/errorH');

exports.createDisease = async(req,res,next) => {
	// console.log(req.body);
	// req.body.user = req.user.id;
	const disease = await Disease.create(req.body);
	
	res.status(201).json({
		success:true,
		disease 
	})
}

exports.getDisease = async (req,res,next) => {
	const diseases = await Disease.find();
	// const resPerPage = 4;
	// const productsCount = await Animal.countDocuments();
	// const apiFeatures = new APIFeatures(Animal.find(),req.query).search().filter();
	
	// apiFeatures.pagination(resPerPage);
	// // products = await apiFeatures.query
	// const products = await apiFeatures.query
	// let filteredProductsCount = products.length;

	if(!diseases) {
	return next(new ErrorHandler('my error',400))
	}
	res.status(200).json({
		success: true,
		// count: products.length,
		// productsCount,
 	// 	resPerPage,
 	// 	filteredProductsCount,
 		diseases
		
	})
}

exports.findDisease = async(req,res,next) => {
	 const disease = await Disease.findById(req.params.id);
	 // if(!animal) {
	 // 		return res.status(404).json({
	 // 			success: false,
	 // 			message: 'Animal not found'
	 // 		})
	 // }
	  if(!disease) {
	 		return next(new ErrorHandler('Disease not found',404));
	 }
	 res.status(200).json({
	 	success: true,
	 	disease
	 })
}

exports.updateDisease = async(req,res,next) => {
	let disease = await Disease.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!disease) {
	 		return next(new ErrorHandler('Disease not found',404));
	 }
disease = await Disease.findByIdAndUpdate(req.params.id,req.body,{
	 	new: true,
	 	runValidators:true,
	 	useFindandModify:false
	 })
	 res.status(200).json({
	 	success:true,
	 	disease
	 })
}

exports.deleteDisease = async(req,res,next) =>{
	const disease = await Disease.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!disease) {
	 		return next(new ErrorHandler('Disease not found',404));
	 }
	 await disease.remove();
	 res.status(200).json({
	 	success: true,
	 	message: 'Disease deleted'
	 })
}