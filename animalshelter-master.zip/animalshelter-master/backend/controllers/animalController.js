const Animal = require('../models/animal')
const cloudinary = require('cloudinary')
const ErrorHandler = require('../utils/errorH');
const catchAsyncErrors = require('../middlewares/catchAsyncErrors')
const APIFeatures = require('../utils/apiFeatures');
const Filter = require('bad-words');


exports.createAnimal = async(req,res,next) => {
	// console.log(req.body);
	const result = await cloudinary.v2.uploader.upload(req.body.imgPath, {
        folder: 'avatar/animals',
        width: 150,
        crop: "scale"
    })
	let diseases = [];
    if (typeof req.body.Anim_Diseases === 'string') {
        diseases.push(req.body.Anim_Diseases)
    } else {
        diseases = req.body.Anim_Diseases
    }
    console.log(diseases);

    let newDisease= [];

    for (let i = 0; i < diseases.length; i++) {
        const disease = diseases[i];
        newDisease.push({
            disease
        })
    }
    console.log(newDisease);

    let injuries = [];
    if (typeof req.body.Anim_Injuries === 'string') {
        injuries.push(req.body.Anim_Injuries)
    } else {
        injuries = req.body.Anim_Injuries
    }
    console.log(injuries);

    let newInjury= [];

    for (let i = 0; i < injuries.length; i++) {
        const injury = injuries[i];
        newInjury.push({
            injury
        })
    }
    console.log(newInjury);

     const newAnimalData = {
        Anim_Name: req.body.Anim_Name,
        Anim_Type: req.body.Anim_Type,
        Anim_Breed: req.body.Anim_Breed,
        Anim_Gender: req.body.Anim_Gender,
        Anim_Age: req.body.Anim_Age,
        Anim_Diseases: newDisease,
        Anim_Injuries: newInjury,
        imgPath: {
        	public_id: result.public_id,
        	url: result.secure_url
        }
    }

    // const animal = await Animal.create(req.body);
	const animals = await Animal.create(newAnimalData);
	
	res.status(201).json({
		success:true,
		animals 
	})
}

exports.AdoptableAnimals = async (req,res,next) => {
	// const animal = await Animal.find();
	const resPerPage = 4;
	const animalsCount = await Animal.countDocuments();
	const apiFeatures = new APIFeatures(Animal.find(
		{Health_Status: 'Cured', Adoption_Status: 'Not Adopted'}),req.query).search().filter();
	
	apiFeatures.pagination(resPerPage);
	// // products = await apiFeatures.query
	const animals = await apiFeatures.query
	let filteredAnimalCount = animals.length;

	if(!animals) {
	return next(new ErrorHandler('my error',400))
	}
	res.status(200).json({
		success: true,
		// count: animal.length,
		animalsCount,
 		resPerPage,
 		filteredAnimalCount,
 		animals
	})
}

exports.fetchAnimals = async (req,res,next) => {
	const animals = await Animal.find()
	.populate('Anim_Diseases.disease', 'Dis_Name')
	.populate('Anim_Injuries.injuries', 'Inj_Name');

	if(!animals) {
	return next(new ErrorHandler('my error',400))
	}
	res.status(200).json({
		success: true,

 		animals
		
	})
}

exports.getAnimBreeds = async (req,res,next) => {
	const breeds  = await Animal.find({}).select(['Anim_Breed']);
	res.status(200).json({
		success: true,
 		breeds 
	})
}

exports.findAnimal = async(req,res,next) => {
	 // const animal = await Animal.findById(req.params.id);

	 const animal = await Animal.findById(req.params.id)
	 	 .populate('Anim_Diseases', 'Dis_Name')
	 	 .populate('Anim_Injuries', 'Inj_Name')
	 	 .populate('comments.user', 'name');

	 console.log(animal)
	 // const injuries = await Animal.findById(req.params.id).populate({
	 // 	path: 'Health_Status',
	 // 	select: ['Inj_Name']
	 // });
	 // if(!animal) {
	 // 		return res.status(404).json({
	 // 			success: false,
	 // 			message: 'Animal not found'
	 // 		})
	 // }
	  if(!animal) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
	 res.status(200).json({
	 	success: true,
	 	animal
	 })
}

exports.updateAnimal = async(req,res,next) => {


	const newAnimalData = {
        Anim_Name: req.body.Anim_Name,
        Anim_Type: req.body.Anim_Type,
        Anim_Breed: req.body.Anim_Breed,
        Anim_Gender: req.body.Anim_Gender,
        Anim_Age: req.body.Anim_Age
    }
	
	if (req.body.imgPath !== '') {
        const animal = await Animal.findById(req.params.id)
        const image_id = animal.imgPath.public_id;
        const res = await cloudinary.v2.uploader.destroy(image_id);
        const result = await cloudinary.v2.uploader.upload(req.body.imgPath, {
            folder: 'avatar/animals',
            width: 150,
            crop: "scale"
        })
        newAnimalData.imgPath = {
            public_id: result.public_id,
            url: result.secure_url
        }
    }
    const animal = await Animal.findByIdAndUpdate(req.params.id, newAnimalData, {
        new: true,
        runValidators: true,
        // useFindAndModify: false
    })
    res.status(200).json({
        success: true,
        animal
    })

	
}

exports.deleteAnimal = async(req,res,next) =>{
	const animal = await Animal.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!animal) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
	 await animal.remove();
	 res.status(200).json({
	 	success: true,
	 	message: 'Animal deleted'
	 })
}

exports.getSickAnimals = async (req,res,next) => {
	const animals  = await Animal.find({Health_Status: 'Not Cured'});

	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
	res.status(200).json({
		success: true,
 		animals 
	})
}

exports.treatAnimal = async(req,res,next) => {
	let animals = await Animal.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
// 	 req.body.Health_Status = 'Cured'
// 	 const CuredStatus = req.body.Health_Status
	console.log(animals)
	const cureData = {
		Anim_Diseases: null,
		Anim_Injuries: null,
		Health_Status: 'Cured'
	}
	animals = await Animal.findByIdAndUpdate(req.params.id,cureData)

	 res.status(200).json({
	 	success:true,
	 	animals
	 })
}

exports.requestAdoption = async(req,res,next) => {
	let animals = await Animal.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
// 	 req.body.Health_Status = 'Cured'
// 	 const CuredStatus = req.body.Health_Status
	console.log(animals)
	const requestDate = Date();
	
	const requestData = {
		Adoption_Status: "Requesting",
		adoption: {
			user: req.user._id,
			requested_at: requestDate
		}
	}
	animals = await Animal.findByIdAndUpdate(req.params.id,requestData)

	 res.status(200).json({
	 	success:true,
	 	animals
	 })
}

exports.getAdoptionRequests = async (req,res,next) => {
	const animals  = await Animal.find({Adoption_Status: 'Requesting'}).select(['Anim_Name','Anim_Type','Anim_Breed','Health_Status','adoption.user','adoption.requested_at'])
		.populate('adoption.user', 'name');

	console.log(animals)
	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
	res.status(200).json({
		success: true,
 		animals 
	})
}

exports.approveAdoption = async(req,res,next) => {
	let animals = await Animal.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
// 	 req.body.Health_Status = 'Cured'
// 	 const CuredStatus = req.body.Health_Status
	console.log(animals)
	const adoptedDate = Date();
	const approveData = {
		Adoption_Status: 'Adopted',
		adoption: {
			user: animals.adoption.user,
			date_adopted: adoptedDate
		}
	}
	animals = await Animal.findByIdAndUpdate(req.params.id,approveData)

	 res.status(200).json({
	 	success:true,
	 	animals
	 })
}

exports.removeRequest = async(req,res,next) => {
	let animals = await Animal.findById(req.params.id);
	// if(!animal) {
	//  		return res.status(404).json({
	//  			success: false,
	//  			message: 'Animal not found'
	//  		})
	//  }
	if(!animals) {
	 		return next(new ErrorHandler('Animal not found',404));
	 }
// 	 req.body.Health_Status = 'Cured'
// 	 const CuredStatus = req.body.Health_Status
	console.log(animals)
	const removeRequestData = {
		Adoption_Status: 'Not Adopted',
		adoption: {
			user: null,
			requested_at: null
		}
	}
	animals = await Animal.findByIdAndUpdate(req.params.id,removeRequestData)

	 res.status(200).json({
	 	success:true,
	 	animals
	 })
}

exports.commentAnimal = async(req,res,next) => {
	const filter = new Filter({'placeholder': '*'});
    const commentFilter = filter.clean(req.body.comment);
	// const { animalId } = req.body;

	const commentData = {
		user: req.user._id,
		// name: req.user.name,
		comment: commentFilter
	}

	const animals = await Animal.findById(req.body.animalId);

	const isFiltered = animals.comments.find(
		r => r.user.toString() === req.user._id.toString()
		)
	if (isFiltered) {
		animals.comments.forEach(review => {
			if (review.user.toString() === req.user._id.toString()) {
				review.comment = commentFilter;
			}
		})
	} else {
		animals.comments.push(commentData);
	}
	await animals.save({ validateBeforeSave: false });
	res.status(200).json({
		success: true
	})
}

exports.getAdoptedAnimals = async(req,res,next) => {
	const animals = await Animal.find({ 'adoption.user': req.user.id,  Adoption_Status: "Adopted"})
// console.log(req.user)
    res.status(200).json({
        success: true,
        animals
    })
}

exports.getRescuedChart = async(req,res,next) => {
    const animals = await Animal.find({}).select(['Date_Rescued']);
    res.status(200).json({
        success:true,
        animals
    })
}

exports.getAdoptedChart = async(req,res,next) => {
    const animals = await Animal.find({'adoption.date_adopted': {$ne: null}}).select(['adoption.date_adopted']);
    res.status(200).json({
        success:true,
        animals
    })
}