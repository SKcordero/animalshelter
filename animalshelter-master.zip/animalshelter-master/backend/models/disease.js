const mongoose = require('mongoose')

const DiseaseSchema = new mongoose.Schema({
	Dis_Name: {
		type: String,
		required: [true, 'Please enter disease name'],
		maxlength: [50, 'Disease name is too long']
	},
	Dis_Info: {
		type: String,
		required: [true, 'Please enter disease info'],
		maxlength: [500, 'Disease info is too long']
	}
})

module.exports = mongoose.model('Disease', DiseaseSchema);