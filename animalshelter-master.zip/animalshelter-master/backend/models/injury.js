const mongoose = require('mongoose')

const InjurySchema = new mongoose.Schema({
	Inj_Name: {
		type: String,
		required: [true, 'Please enter injury name'],
		maxlength: [50, 'Injury name is too long']
	},
	Inj_Info: {
		type: String,
		required: [true, 'Please enter injury info'],
		maxlength: [500, 'Injury info is too long']
	}
})

module.exports = mongoose.model('Injury', InjurySchema);