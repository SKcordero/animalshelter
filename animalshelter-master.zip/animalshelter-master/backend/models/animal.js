const mongoose = require('mongoose')

const AnimalSchema = new mongoose.Schema({
	Anim_Name: {
		type: String,
		required: [true, 'Please enter animal name'],
		maxlength: [50, 'Animal name is too long']
	},
	Anim_Type: {
		type: String,
		required: [true, 'Please enter animal type'],
		enum: {
			values: [
				'Dog',
				'Cat'
			],
			message: 'Select only available animal type'
		}
	},
	Anim_Breed: {
		type: String,
		required: [true, 'Please enter animal breed'],
		maxlength: [50, 'Animal breed too long']
	},
	Anim_Gender: {
		type: String,
		required: [true, 'Please enter animal gender'],
		enum: {
			values: [
				'Male',
				'Female'
			],
			message: 'Select only available animal gender'
		}
	},
	Anim_Age: {
		type: Number,
		required: [true, 'Please enter animal age'],
		maxlength: [100, 'Animal age is too long']
	},
	Health_Status: {
		type: String,
		default: 'Not Cured',
		enum: {
			values: [
				'Cured',
				'Not Cured'
			],
			message: 'Status is inappropriate'
		}
	},
	Adoption_Status: {
		type: String,
		default: 'Not Adopted',
		enum: {
			values: [
				'Adopted',
				'Requesting',
				'Not Adopted'
			],
			message: 'Status is inappropriate'
		}
	},
	Anim_Diseases: [
        {
            disease: {
                type: mongoose.Schema.ObjectId,
                ref: 'Disease'
            }
        }
    ],
	Anim_Injuries: [
        {
            injuries: {
                type: mongoose.Schema.ObjectId,
                ref: 'Injury'
            }
        }
    ],
	adoption: {
		user: {
	    	type: mongoose.Schema.ObjectId,
	    	ref: 'User',
	    },
	    requested_at:{
	    	type: Date
	    },
	    date_adopted:{
	    	type: Date
	    },
	},
	Date_Rescued: {
		type: Date,
		default: Date.now
		// maxlength: [50, 'Animal type is too long']
	},
	imgPath: 
        {
            public_id: {
                type: String,
                required: true
            },
            url: {
                type: String,
                required: true
            },
        },
    comments: [
    	{
    		user: {
    			type: mongoose.Schema.ObjectId,
    			ref: 'User',
    			required: true
    		},
    		comment: {
    			type: String,
    			required: true
    		}
    	}
    ]
})

module.exports = mongoose.model('Animal', AnimalSchema);