// import logo from './logo.svg';
import './App.css';
import React, {useEffect} from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Header from './components/layouts/Header'
import Home from './components/Home'
import AnimalDetails from './components/animal/AnimalDetails'
import Login from './components/user/login'
import Register from './components/user/register'
import Profile from './components/user/profile'
import ProtectedRoute from './components/route/ProtectedRoute'
import UpdatePassword from './components/user/UpdatePassword'
import UpdateProfile from './components/user/UpdateProfile'
import ForgotPassword from './components/user/ForgotPassword'
import NewPassword from './components/user/NewPassword'

import ListDiseases from './components/admin/diseaseCRUD'
import Dashboard from './components/admin/Dashboard'
import NewDisease from './components/admin/diseaseCREATE'
import UpdateDisease from './components/admin/diseaseUPDATE'

import ListInjuries from './components/admin/injuryCRUD'
import NewInjury from './components/admin/injuryCREATE'
import UpdateInjury from './components/admin/injuryUPDATE'

import ListUsers from './components/admin/userCRUD'
import NewUser from './components/admin/userCREATE'
import UpdateUser from './components/admin/userUPDATE'

import ListSickAnimals from './components/admin/treatAnimal'
import ListAdoptionRequests from './components/admin/adoptionAnimal'

import ListAnimals from './components/admin/animalCRUD'
import NewAnimal from './components/admin/animalCREATE'
import UpdateAnimal from './components/admin/animalUPDATE'

import ListAdopters from './components/admin/adopterChangeStatus'

import AdoptedAnimals from './components/user/AdoptedAnimals'

import RescuedCharts from './components/admin/RescuedChart'
import AdoptedCharts from './components/admin/AdoptedChart'

import { loadUser } from './actions/userActions'
import store from './store'
function App() {

  useEffect(() => {
    store.dispatch(loadUser())
    }, [])
   
  return (
    <Router>
      <div className="App">
        <Header />
          <Routes>
            {/*<Home />*/}
            
            <Route path="/animal/:id" element={<AnimalDetails />} exact="true" />

            <Route path="/" element={<Home />} exact="true" />
            <Route path="/search/:keyword" element={<Home />} exact="true" />
            <Route path="/login" element={<Login />} exact="true" />
            <Route path="/register" element={<Register />} exact="true" />
            {/*<Route path="/me" element={<Profile />} exact="true" />*/}
            <Route
              path="/me" element={
                <ProtectedRoute>
                <Profile />
                </ProtectedRoute>
              } exact="true" />
              <Route
              path="/password/update" element={
                <ProtectedRoute>
                <UpdatePassword />
                </ProtectedRoute>
              } exact="true" />
              <Route
              path="/me/update" element={
                <ProtectedRoute>
                <UpdateProfile />
                </ProtectedRoute>
              } exact="true" />
              <Route path="/password/forgot" element={<ForgotPassword />} exact="true" />
              <Route path="/password/reset/:token" element={<NewPassword />} exact="true" />
              <Route
              path="/diseases" element={
                <ProtectedRoute>
                <ListDiseases />
                </ProtectedRoute>
              } exact="true" />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <Dashboard />
                  </ProtectedRoute>
                } exact="true" />
                <Route
                path="/disease/new"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <NewDisease />
                  </ProtectedRoute>
                } exact="true" />
                <Route
                path="/disease/:id"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <UpdateDisease />
                  </ProtectedRoute>
                } exact="true" />

                <Route
              path="/injuries" element={
                <ProtectedRoute>
                <ListInjuries />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/injury/new" element={
                <ProtectedRoute>
                <NewInjury />
                </ProtectedRoute>
              } exact="true" />

              <Route
                path="/injury/:id"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <UpdateInjury />
                  </ProtectedRoute>
                } exact="true" />

              <Route
              path="/admin/users" element={
                <ProtectedRoute>
                <ListUsers />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/user/new" element={
                <ProtectedRoute>
                <NewUser />
                </ProtectedRoute>
              } exact="true" />

              <Route
                path="/admin/user/:id"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <UpdateUser />
                  </ProtectedRoute>
                } exact="true" />

              <Route
              path="/animals/sick" element={
                <ProtectedRoute>
                <ListSickAnimals />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/animals/requests" element={
                <ProtectedRoute>
                <ListAdoptionRequests />
                </ProtectedRoute>
              } exact="true" />

              {/*<Route
              path="/animal/:id" element={
                <ProtectedRoute>
                <DisplayComments />
                </ProtectedRoute>
              } exact="true" />
*/}
              <Route
              path="/animals" element={
                <ProtectedRoute>
                <ListAnimals />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/animal/new" element={
     
                <NewAnimal />
  
              } exact="true" />

              <Route
                path="/animalUpdate/:id"
                element={
                  <ProtectedRoute isAdmin={true}>
                    <UpdateAnimal />
                  </ProtectedRoute>
                } exact="true" />

                <Route
              path="/admin/adopters" element={
                <ProtectedRoute>
                <ListAdopters />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/me/adopted" element={
                <ProtectedRoute>
                <AdoptedAnimals />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/rescuedChart" element={
                <ProtectedRoute>
                <RescuedCharts />
                </ProtectedRoute>
              } exact="true" />

              <Route
              path="/adoptedChart" element={
                <ProtectedRoute>
                <AdoptedCharts />
                </ProtectedRoute>
              } exact="true" />
          </Routes>

      </div>
     </Router>
  );
}

export default App;
