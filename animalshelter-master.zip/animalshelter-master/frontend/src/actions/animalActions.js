import axios from 'axios';
import { 
	ALL_ANIMALS_REQUEST,
	ALL_ANIMALS_SUCCESS, 
	ALL_ANIMALS_FAIL,

	CURE_ANIMALS_REQUEST, 
	CURE_ANIMALS_SUCCESS, 
	CURE_ANIMALS_FAIL,

	SICK_ANIMALS_REQUEST,
	SICK_ANIMALS_SUCCESS, 
	SICK_ANIMALS_FAIL,

	ANIMAL_DETAILS_REQUEST,
  	ANIMAL_DETAILS_SUCCESS,
    ANIMAL_DETAILS_FAIL,

    ALL_BREEDS_REQUEST,
    ALL_BREEDS_SUCCESS,
    ALL_BREEDS_FAIL,

    REQUEST_ADOPTION_REQUEST,
    REQUEST_ADOPTION_SUCCESS,
    REQUEST_ADOPTION_FAIL,

    ALL_REQUESTS_REQUEST,
    ALL_REQUESTS_SUCCESS,
    ALL_REQUESTS_FAIL,

    APPROVE_ADOPTION_REQUEST,
    APPROVE_ADOPTION_SUCCESS,
    APPROVE_ADOPTION_FAIL,

    REMOVE_REQUEST_REQUEST,
    REMOVE_REQUEST_SUCCESS,
    REMOVE_REQUEST_FAIL,

    NEW_COMMENT_REQUEST,
    NEW_COMMENT_SUCCESS,
    NEW_COMMENT_FAIL,

    GET_ANIMALS_REQUEST,
    GET_ANIMALS_SUCCESS,
    GET_ANIMALS_FAIL,

    DELETE_ANIMALS_REQUEST,
    DELETE_ANIMALS_SUCCESS,
    DELETE_ANIMALS_FAIL,

    NEW_ANIMALS_REQUEST,
    NEW_ANIMALS_SUCCESS,
    NEW_ANIMALS_FAIL,

    UPDATE_ANIMAL_REQUEST,
    UPDATE_ANIMAL_SUCCESS,
    UPDATE_ANIMAL_FAIL,

    ADOPTED_ANIMALS_REQUEST,
    ADOPTED_ANIMALS_SUCCESS,
    ADOPTED_ANIMALS_FAIL,

    RESCUED_CHARTS_REQUEST,
    RESCUED_CHARTS_SUCCESS,
    RESCUED_CHARTS_FAIL,

    ADOPTED_CHARTS_REQUEST,
    ADOPTED_CHARTS_SUCCESS,
    ADOPTED_CHARTS_FAIL,

	CLEAR_ERRORS 
} from '../constants/animalConstants';
export const AdoptableAnimals  = (currentPage = 1, keyword = '', ageAnimal, category, gender, breed) => async (dispatch) => {
	try {
		dispatch({
			type: ALL_ANIMALS_REQUEST
		})
		let link = `/api/v1/home?keyword=${keyword}&page=${currentPage}&Anim_Age[lte]=${ageAnimal[1]}&Anim_Age[gte]=${ageAnimal[0]}`
 		// const { data }   = await axios.get(link);

 		if(category){
 			link = `/api/v1/home?keyword=${keyword}&page=${1}&Anim_Age[lte]=${ageAnimal[1]}&Anim_Age[gte]=${ageAnimal[0]}&Anim_Type=${category}`
 		}

 		if(gender){
 			link = `/api/v1/home?keyword=${keyword}&page=${1}&Anim_Age[lte]=${ageAnimal[1]}&Anim_Age[gte]=${ageAnimal[0]}&Anim_Gender=${gender}`
 		}

 		if(breed){
 			link = `/api/v1/home?keyword=${keyword}&page=${1}&Anim_Age[lte]=${ageAnimal[1]}&Anim_Age[gte]=${ageAnimal[0]}&Anim_Breed=${breed}`
 		}

 		const { data }   = await axios.get(link);
		dispatch({
			type: ALL_ANIMALS_SUCCESS,
			payload: data
		})
	} catch(error) {
		dispatch({
			type: ALL_ANIMALS_FAIL,
			payload: error.response.data.message
		})
	}
}
export const clearErrors = () => async (dispatch) =>{
	dispatch({
		type: CLEAR_ERRORS
	})
}
export const getAnimalDetails = (id) => async (dispatch) => {
    try {
        dispatch({ type: ANIMAL_DETAILS_REQUEST })
        const { data } = await axios.get(`/api/v1/animal/${id}`)
        dispatch({
            type: ANIMAL_DETAILS_SUCCESS,
            payload: data.animal
        })
    } catch (error) {
        dispatch({
            type: ANIMAL_DETAILS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const getAnimBreeds = () => async (dispatch) =>{
    try {
    	dispatch({ type: ALL_BREEDS_REQUEST})

    	const { data } = await axios.get(`/api/v1/animalBreed`)

    	dispatch({
    		type: ALL_BREEDS_SUCCESS,
    		payload: data.breeds 
    	})
    } catch (error) {
    	dispatch({
    		type: ALL_BREEDS_FAIL,
    		payload: error.response.data.message
    	})
    }
}

export const getSickAnimals = () => async (dispatch) => {
    try {

        dispatch({ type: SICK_ANIMALS_REQUEST });

        const { data } = await axios.get(`/api/v1/animals/sick`)

        dispatch({
            type: SICK_ANIMALS_SUCCESS,
            payload: data
        })

    } catch (error) {
        dispatch({
            type: SICK_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const cureAnimal = (id) => async (dispatch) => {
    try {

        dispatch({ type: CURE_ANIMALS_REQUEST })

        const { data } = await axios.put(`/api/v1/animals/sick/${id}`)

        dispatch({
            type: CURE_ANIMALS_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: CURE_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const requestAnimalAdoption = (id) => async (dispatch) => {
    try {

        dispatch({ type: REQUEST_ADOPTION_REQUEST })

        const { data } = await axios.put(`/api/v1/request/${id}`)

        dispatch({
            type: REQUEST_ADOPTION_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: REQUEST_ADOPTION_FAIL,
            payload: error.response.data.message
        })
    }
}

export const getAdoptionRequests = () => async (dispatch) => {
    try {

        dispatch({ type: ALL_REQUESTS_REQUEST });

        const { data } = await axios.get(`/api/v1/animals/requests`)

        dispatch({
            type: ALL_REQUESTS_SUCCESS,
            payload: data
        })

    } catch (error) {
        dispatch({
            type: ALL_REQUESTS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const approveAdoptionRequest = (id) => async (dispatch) => {
    try {

        dispatch({ type: APPROVE_ADOPTION_REQUEST })

        const { data } = await axios.put(`/api/v1/animals/requests/${id}`)

        dispatch({
            type: APPROVE_ADOPTION_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: APPROVE_ADOPTION_FAIL,
            payload: error.response.data.message
        })
    }
}

export const removeAdoptionRequest = (id) => async (dispatch) => {
    try {

        dispatch({ type: REMOVE_REQUEST_REQUEST })

        const { data } = await axios.put(`/api/v1/animals/requests/remove/${id}`)

        dispatch({
            type: REMOVE_REQUEST_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: REMOVE_REQUEST_FAIL,
            payload: error.response.data.message
        })
    }
}

export const newCommentAnimal = (commentData) => async (dispatch) => {
    try {

        dispatch({ type: NEW_COMMENT_REQUEST })

        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const { data } = await axios.post('/api/v1/animals/comment', commentData, config)

        dispatch({
            type: NEW_COMMENT_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: NEW_COMMENT_FAIL,
            payload: error.response.data.message
        })
    }
}

export const allAnimals = () => async (dispatch) => {
    try {

        dispatch({ type: GET_ANIMALS_REQUEST });

        const { data } = await axios.get(`/api/v1/animals`)

        dispatch({
            type: GET_ANIMALS_SUCCESS,
            payload: data
        })

    } catch (error) {
        dispatch({
            type: GET_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const deleteAnimal = (id) => async (dispatch) => {
    try {

        dispatch({ type: DELETE_ANIMALS_REQUEST })

        const { data } = await axios.delete(`/api/v1/animal/${id}`)

        dispatch({
            type: DELETE_ANIMALS_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: DELETE_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const newAnimals = (animalData) => async (dispatch) => {
    try {

        dispatch({ type: NEW_ANIMALS_REQUEST })

        const config = {
            headers: {
                'Content-Type': 'application/json',
                
            }
        }

        const { data } = await axios.post(`/api/v1/animal/new`, animalData, config)

        dispatch({
            type: NEW_ANIMALS_SUCCESS,
            payload: data
        })

    } catch (error) {
        dispatch({
            type: NEW_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const updateAnimal = (id, animalData) => async (dispatch) => {
    try {

        dispatch({ type: UPDATE_ANIMAL_REQUEST })

        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }

        const { data } = await axios.put(`/api/v1/animalUpdate/${id}`, animalData, config)

        dispatch({
            type: UPDATE_ANIMAL_SUCCESS,
            payload: data.success
        })

    } catch (error) {
        dispatch({
            type: UPDATE_ANIMAL_FAIL,
            payload: error.response.data.message
        })
    }
}

export const getAdoptedAnimals = () => async (dispatch) => {
    try {
        dispatch({ type: ADOPTED_ANIMALS_REQUEST })
        const { data } = await axios.get(`/api/v1/me/adopted`)
        dispatch({
            type: ADOPTED_ANIMALS_SUCCESS,
            payload: data.animals
        })
    } catch (error) {
        dispatch({
            type: ADOPTED_ANIMALS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const rescuedCharts = () => async (dispatch) => {
    try {
        dispatch({ type: RESCUED_CHARTS_REQUEST })
        const { data } = await axios.get(`/api/v1/rescuedChart`)
        dispatch({
            type: RESCUED_CHARTS_SUCCESS,
            payload: data.animals
        })
    } catch (error) {
        dispatch({
            type: RESCUED_CHARTS_FAIL,
            payload: error.response.data.message
        })
    }
}

export const adoptedCharts = () => async (dispatch) => {
    try {
        dispatch({ type: ADOPTED_CHARTS_REQUEST })
        const { data } = await axios.get(`/api/v1/adoptedChart`)
        dispatch({
            type: ADOPTED_CHARTS_SUCCESS,
            payload: data.animals
        })
    } catch (error) {
        dispatch({
            type: ADOPTED_CHARTS_FAIL,
            payload: error.response.data.message
        })
    }
}