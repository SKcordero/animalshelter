import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension'
import { animalsReducer, animalDetailsReducer, animBreedsReducer, sickAnimalsReducer, cureAnimalsReducer, requestAdoptionReducer, getAdoptionRequestsReducer, approveAdoptionRequestReducer, removeAdoptionRequestReducer, newCommentAnimalReducer, newAnimalReducer, createAnimalReducer, getAnimalsReducer, getAdoptedAnimalsReducers, rescuedChartsReducers, adoptedChartsReducers  } from './reducers/animalReducers'
import { authReducer, userReducer, forgotPasswordReducer, newUserReducer, allUsersReducer, userDetailsReducer, getAllAdoptersReducers, changeUserStatusReducer} from './reducers/userReducers'
import { allDiseasesReducer, diseaseReducer, newDiseaseReducer, diseaseDetailsReducer } from './reducers/diseaseReducers'
import { allInjuriesReducer, injuryReducer, newInjuryReducer, injuryDetailsReducer } from './reducers/injuryReducers'
const reducer = combineReducers({
    animals: animalsReducer,
    animalDetails: animalDetailsReducer,
    getSickAnimals: sickAnimalsReducer,
    cureAnimal :cureAnimalsReducer,
    auth: authReducer,
    forgotPassword: forgotPasswordReducer,
    getBreeds: animBreedsReducer,

    getDiseases: allDiseasesReducer,
    disease: diseaseReducer,
    newDisease: newDiseaseReducer,
    diseaseDetails: diseaseDetailsReducer,

    getInjuries: allInjuriesReducer,
    injury: injuryReducer,
    newInjury: newInjuryReducer,
    injuryDetails: injuryDetailsReducer,

    allUsers: allUsersReducer,
    user: userReducer,
    newUser: newUserReducer,
    userDetails: userDetailsReducer,

    requestAdoption: requestAdoptionReducer,
    getAdoptionRequests: getAdoptionRequestsReducer,
    approveAdoption: approveAdoptionRequestReducer,
    removeRequest: removeAdoptionRequestReducer,

    newComment :newCommentAnimalReducer,

    newAnimals: newAnimalReducer,
    createAnimal: createAnimalReducer,
    allAnimals: getAnimalsReducer,

    getAdopters: getAllAdoptersReducers,
    changeStatus: changeUserStatusReducer,
    getAdoptedAnimals: getAdoptedAnimalsReducers,

    rescuedChart: rescuedChartsReducers,
    adoptedChart: adoptedChartsReducers
})

let initialState = {
}

const middlware = [thunk]
const store = createStore(reducer, initialState, composeWithDevTools(applyMiddleware(...middlware)))

export default store;