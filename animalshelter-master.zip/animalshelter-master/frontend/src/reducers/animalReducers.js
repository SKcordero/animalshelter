import { 
    ALL_ANIMALS_REQUEST,
	ALL_ANIMALS_SUCCESS, 
	ALL_ANIMALS_FAIL,

    SICK_ANIMALS_REQUEST,
    SICK_ANIMALS_SUCCESS, 
    SICK_ANIMALS_FAIL,

    CURE_ANIMALS_REQUEST,
    CURE_ANIMALS_SUCCESS, 
    CURE_ANIMALS_FAIL,
    CURE_ANIMALS_RESET,

	ANIMAL_DETAILS_REQUEST,
  	ANIMAL_DETAILS_SUCCESS,
    ANIMAL_DETAILS_FAIL,

    ALL_BREEDS_REQUEST,
    ALL_BREEDS_SUCCESS,
    ALL_BREEDS_FAIL,

    REQUEST_ADOPTION_REQUEST,
    REQUEST_ADOPTION_SUCCESS, 
    REQUEST_ADOPTION_FAIL,
    REQUEST_ADOPTION_RESET,

    ALL_REQUESTS_REQUEST,
    ALL_REQUESTS_SUCCESS,
    ALL_REQUESTS_FAIL,

    APPROVE_ADOPTION_REQUEST,
    APPROVE_ADOPTION_SUCCESS, 
    APPROVE_ADOPTION_FAIL,
    APPROVE_ADOPTION_RESET,

    REMOVE_REQUEST_REQUEST,
    REMOVE_REQUEST_SUCCESS,
    REMOVE_REQUEST_FAIL,
    REMOVE_REQUEST_RESET,

    NEW_COMMENT_REQUEST,
    NEW_COMMENT_SUCCESS,
    NEW_COMMENT_RESET,
    NEW_COMMENT_FAIL,

    GET_ANIMALS_REQUEST,
    GET_ANIMALS_SUCCESS,
    GET_ANIMALS_FAIL,

    DELETE_ANIMALS_REQUEST,
    DELETE_ANIMALS_SUCCESS,
    DELETE_ANIMALS_FAIL,
    DELETE_ANIMALS_RESET,

    NEW_ANIMALS_REQUEST,
    NEW_ANIMALS_SUCCESS,
    NEW_ANIMALS_FAIL,
    NEW_ANIMALS_RESET,

    UPDATE_ANIMAL_REQUEST,
    UPDATE_ANIMAL_SUCCESS,
    UPDATE_ANIMAL_RESET,

    ADOPTED_ANIMALS_REQUEST,
    ADOPTED_ANIMALS_SUCCESS,
    ADOPTED_ANIMALS_FAIL,

    RESCUED_CHARTS_REQUEST,
    RESCUED_CHARTS_SUCCESS,
    RESCUED_CHARTS_FAIL,

    ADOPTED_CHARTS_REQUEST,
    ADOPTED_CHARTS_SUCCESS,
    ADOPTED_CHARTS_FAIL,

	CLEAR_ERRORS 
} from '../constants/animalConstants'

export const animalsReducer = (state = { animals:[] }, action) => {
	switch(action.type) {
		case ALL_ANIMALS_REQUEST:
		return {
			loading: true,
			animals:[]
		}

		case ALL_ANIMALS_SUCCESS:
		return {
			loading:false,
			animals: action.payload.animals,
			animalsCount: action.payload.animalsCount,
			resPerPage: action.payload.resPerPage,
			filteredAnimalsCount: action.payload.filteredAnimalsCount
		}

		case ALL_ANIMALS_FAIL:
		return {
			loading:false,
			error: action.payload
		}

		case CLEAR_ERRORS:
		return {
			...state,
			error: null
		}
		default:
		return state;
	}
}

export const sickAnimalsReducer = (state = { animals: [] }, action) => {
    switch (action.type) {

        case SICK_ANIMALS_REQUEST:
            return {
                loading: true
            }

        case SICK_ANIMALS_SUCCESS:
            return {
                loading: false,
                animals: action.payload.animals
            }

        case SICK_ANIMALS_FAIL:
            return {
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const cureAnimalsReducer = (state = {}, action) => {
    switch (action.type) {

        case CURE_ANIMALS_REQUEST:
            return {
                ...state,
                loading: true
            }

        case CURE_ANIMALS_SUCCESS:
            return {
                ...state,
                loading: false,
                isCured: action.payload
            }

        case CURE_ANIMALS_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }

        case CURE_ANIMALS_RESET:
            return {
                ...state,
                loading: false,
                isCured: false
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const animalDetailsReducer = (state = { animal: {} }, action) => {
    switch (action.type) {
        case ANIMAL_DETAILS_REQUEST:
            return {
                ...state,
                loading: true
            }
        case ANIMAL_DETAILS_SUCCESS:
            return {
                loading: false,
                animal: action.payload
            }
        case ANIMAL_DETAILS_FAIL:
            return {
                ...state,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }
        default:
            return state
    }
}

export const animBreedsReducer = (state = { breeds : [] }, action) => {
    switch (action.type) {
        case ALL_BREEDS_REQUEST:
            return {
                // ...state,
                loading: true,
                breeds :[]
            }
        case ALL_BREEDS_SUCCESS:
            return {
                ...state,
                loading: false,
                breeds : action.payload
            }
        case ALL_BREEDS_FAIL:
            return {
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }
        default:
        return state
    }
}

export const requestAdoptionReducer = (state = { }, action) => {
    switch (action.type) {
        case REQUEST_ADOPTION_REQUEST:
        // case APPROVE_ADOPTION_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case REQUEST_ADOPTION_SUCCESS:
            return {
                ...state,
                loading: false,
                isRequested: action.payload
            }
        case REQUEST_ADOPTION_RESET:
            return {
                ...state,
                isRequested: false
            }
        // case APPROVE_ADOPTION_SUCCESS:
        //     return {
        //         ...state,
        //         loading: false,
        //         isApproved: action.payload
        //     }
        // case APPROVE_ADOPTION_RESET:
        //     return {
        //         ...state,
        //         isApproved: false
        //     }    
        case REQUEST_ADOPTION_FAIL:
        // case APPROVE_ADOPTION_FAIL:
            return {
                ...state,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }
        default:
            return state
    }
}

export const getAdoptionRequestsReducer = (state = { animals: [] }, action) => {
    switch (action.type) {

        case ALL_REQUESTS_REQUEST:
            return {
                loading: true
            }

        case ALL_REQUESTS_SUCCESS:
            return {
                loading: false,
                animals: action.payload.animals
            }

        case ALL_REQUESTS_FAIL:
            return {
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const approveAdoptionRequestReducer = (state = {}, action) => {
    switch (action.type) {

        case APPROVE_ADOPTION_REQUEST:
            return {
                ...state,
                loading: true
            }

        case APPROVE_ADOPTION_SUCCESS:
            return {
                ...state,
                loading: false,
                isApproved: action.payload
            }

        case APPROVE_ADOPTION_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }

        case APPROVE_ADOPTION_RESET:
            return {
                ...state,
                loading: false,
                isApproved: false
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const removeAdoptionRequestReducer = (state = {}, action) => {
    switch (action.type) {

        case REMOVE_REQUEST_REQUEST:
            return {
                ...state,
                loading: true
            }

        case REMOVE_REQUEST_SUCCESS:
            return {
                ...state,
                loading: false,
                isDenied: action.payload
            }

        case REMOVE_REQUEST_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }

        case REMOVE_REQUEST_RESET:
            return {
                ...state,
                loading: false,
                isDenied: false
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const newCommentAnimalReducer = (state = {}, action) => {
    switch (action.type) {

        case NEW_COMMENT_REQUEST:
            return {
                ...state,
                loading: true
            }

        case NEW_COMMENT_SUCCESS:
            return {
                loading: false,
                isPosted: action.payload
            }

        case NEW_COMMENT_FAIL:
            return {
                ...state,
                error: action.payload
            }

        case NEW_COMMENT_RESET:
            return {
                ...state,
                isPosted: false
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state
    }
}

export const newAnimalReducer = (state = {}, action) => {
    switch (action.type) {

        case UPDATE_ANIMAL_REQUEST:
        case DELETE_ANIMALS_REQUEST:
            return {
                ...state,
                loading: true
            }

        case DELETE_ANIMALS_SUCCESS:
            return {
                ...state,
                loading: false,
                isDeleted: action.payload
            }

        case UPDATE_ANIMAL_SUCCESS:
            return {
                ...state,
                loading: false,
                isUpdated: action.payload
            }

        case UPDATE_ANIMAL_RESET:
            return {
                ...state,
                isUpdated: false
            }

        case DELETE_ANIMALS_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }

        case DELETE_ANIMALS_RESET:
            return {
                ...state,
                isDeleted: false
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const createAnimalReducer = (state = { animals: {} }, action) => {
    switch (action.type) {

        case NEW_ANIMALS_REQUEST:
            return {
                ...state,
                loading: true
            }

        case NEW_ANIMALS_SUCCESS:
            return {
                loading: false,
                success: action.payload.success,
                animals: action.payload.animals
            }

        case NEW_ANIMALS_FAIL:
            return {
                ...state,
                error: action.payload
            }

        case NEW_ANIMALS_RESET:
            return {
                ...state,
                success: false
            }

        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state
    }
}

export const getAnimalsReducer = (state = { animals: [] }, action) => {
    switch (action.type) {

        case GET_ANIMALS_REQUEST:
            return {
                loading: true
            }

        case GET_ANIMALS_SUCCESS:
            return {
                loading: false,
                animals: action.payload.animals
            }

        case GET_ANIMALS_FAIL:
            return {
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const getAdoptedAnimalsReducers = (state = { animals: [] }, action) => {
    switch (action.type) {

        case ADOPTED_ANIMALS_REQUEST:
            return {
                loading: true,
                animals:[]
            }

        case ADOPTED_ANIMALS_SUCCESS:
            return {
                ...state,
                loading: false,
                animals: action.payload
            }

        case ADOPTED_ANIMALS_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const rescuedChartsReducers = (state = { animals: [] }, action) => {
    switch (action.type) {

        case RESCUED_CHARTS_REQUEST:
            return {
                ...state,
                loading: true,
                // animals:[]
            }

        case RESCUED_CHARTS_SUCCESS:
            return {
                ...state,
                loading: false,
                animals: action.payload
            }

        case RESCUED_CHARTS_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}

export const adoptedChartsReducers = (state = { animals: [] }, action) => {
    switch (action.type) {

        case ADOPTED_CHARTS_REQUEST:
            return {
                ...state,
                loading: true,
                // animals:[]
            }

        case ADOPTED_CHARTS_SUCCESS:
            return {
                ...state,
                loading: false,
                animals: action.payload
            }

        case ADOPTED_CHARTS_FAIL:
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            }

        default:
            return state;
    }
}