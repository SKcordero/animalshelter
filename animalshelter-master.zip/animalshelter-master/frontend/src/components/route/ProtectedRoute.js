import React from 'react'
import { Navigate } from 'react-router-dom'
import { useSelector } from 'react-redux'

const ProtectedRoute = ({ isAdmin=false, children}) => {
    const { isAuthenticated } = useSelector(state => state.auth)

    if (isAuthenticated === undefined || isAuthenticated === false){
        return <Navigate to='/login'/>
    }

    return children;
}

export default ProtectedRoute