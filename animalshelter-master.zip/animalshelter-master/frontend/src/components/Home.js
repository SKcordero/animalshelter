import React, { Fragment, useState, useEffect } from 'react'
import MetaData from './layouts/MetaData'
import Animal from './animal/Animal'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from "react-router-dom";
import { AdoptableAnimals, getAnimBreeds } from '../actions/animalActions'
import { rescuedCharts } from '../actions/animalActions'
import { adoptedCharts } from '../actions/animalActions'
import Loader from './layouts/Loader'
import { useAlert } from 'react-alert'
import Pagination from 'react-js-pagination'
import Slider from 'rc-slider'
import 'rc-slider/assets/index.css';


const Home = () => {
	const createSliderWithTooltip = Slider.createSliderWithTooltip;
	const Range = createSliderWithTooltip(Slider.Range);
	const [ageAnimal, setAge] = useState([1, 40]);
	const dispatch = useDispatch();
	const alert = useAlert();

	const {loading,
		animals,
		error, 
		animalsCount, 
		resPerPage } = useSelector(state => state.animals);
	const [currentPage, setCurrentPage] = useState(1)
    
    const [category, setCategory] = useState('');
    const categories = [
        'Dog',
        'Cat'
    ]
    const [gender, setGender] = useState('');
    const genders = [
        'Male',
        'Female'
    ]
    const [breed, setBreed] = useState('');
    const { breeds } = useSelector(state => state.getBreeds);
	let { keyword } = useParams();

    const breedgroups = breeds.reduce(
        (breedgroups, breed) => {
            const thisbreed = breed.Anim_Breed;
            if(!breedgroups[thisbreed]) {
                breedgroups[thisbreed]=[]
            }
            return breedgroups
        }, {}
        )
    console.log(breeds)
    const newbreed = Object.keys(breedgroups)
    // console.log(breed)

	useEffect( () => { 
        dispatch(getAnimBreeds())
        dispatch(rescuedCharts())
        dispatch(adoptedCharts())
		if(error){
			alert.success('success')
			return alert.error(error)
		}

		dispatch(AdoptableAnimals(currentPage, keyword, ageAnimal, category, gender, breed));
	}, [dispatch, alert,error, currentPage, keyword, ageAnimal, category, gender, breed] );

	// let count = animalsCount;
	

	function setCurrentPageNo(pageNumber) {
        setCurrentPage(pageNumber)
    }
    // let count = animalsCount;
    // console.log(count, resPerPage);
    // if (keyword) {
    //     count = filteredAnimalsCount
    // }
    // console.log(count);

	return (
		<Fragment>
		{ loading ? <Loader /> : (
			<Fragment>   
			<MetaData title={'Animal Shelter'} />
			{/*<h1 id="products_heading">Rescued Animals</h1>*/}

			<section id="animals" className="container mt-5">
			<div className="row">

			{keyword ? (
                                <Fragment>
                                <div className="container containerFilter">
                                    <h1 className="FilterTitle">Filter Options:</h1>
                                      <h3 className="alignCenter">Age</h3>
                                            <Range
                                                marks={{
                                                    1: `1`,
                                                    40: `40`
                                                }}
                                                min={1}
                                                max={40}
                                                defaultValue={[1, 40]}
                                                tipFormatter={value => `${value}yr old`}
                                                tipProps={{
                                                    placement: "top",
                                                    visible: true
                                                }}
                                                value={ageAnimal}
                                                onChange={ageAnimal => setAge(ageAnimal)}
                                            />
                                            <div className="mt-5 filterSection">
                                                <h4 className="mb-3">
                                                    Categories
                                                </h4>
                                                <ul className="pl-0">
                                                    {categories.map(category => (
                                                        <li
                                                            style={{
                                                                cursor: 'pointer',
                                                                listStyleType: 'none'
                                                            }}
                                                            key={category}
                                                            onClick={() => setCategory(category)}>
                                                            {category}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        <div className="mt-5 filterSection">
                                                <h4 className="mb-3">
                                                    Gender
                                                </h4>
                                                <ul className="pl-0">
                                                    {genders.map(gender => (
                                                        <li
                                                            style={{
                                                                cursor: 'pointer',
                                                                listStyleType: 'none'
                                                            }}
                                                            key={gender}
                                                            onClick={() => setGender(gender)}>
                                                            {gender}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        <div className="mt-5 filterSection">
                                                <h4 className="mb-3">
                                                    Breed
                                                </h4>
                                                <ul className="pl-0">
                                                    {newbreed.map(animal => (
                                                        <li 
                                                        style={{
                                                                cursor: 'pointer',
                                                                listStyleType: 'none'
                                                            }}
                                                            key={animal}
                                                            onClick={() => setBreed(animal)}>
                                                          {animal}
                                                        </li>
                                                      ))}
                                                </ul>
                                            </div>

                                    </div>


			{/*{animals && animals.map(animal => (
				<Animal key={animal._id } animal={animal} />
				))}
			</div>
			</section>*/}
			

			
                                            {animals.map(animal => (
                                                <Animal key={animal._id} animal={animal} col={4} />
                                            ))}
                                       
                                    
                                </Fragment>
                            ) : (
                                    animals.map(animal => (
                                        <Animal key={animal._id} animal={animal} col={3} />
                                    ))
                                )}
                            
                        </div>
                    </section>

			{/*{resPerPage <= count && */}(
                        <div className="d-flex justify-content-center mt-5">
                            <Pagination
                                activePage={currentPage}
                                itemsCountPerPage={resPerPage}
                                totalItemsCount={animalsCount}
                                onChange={setCurrentPageNo}
                                nextPageText={'Next'}
                                prevPageText={'Prev'}
                                firstPageText={'First'}
                                lastPageText={'Last'}
                                itemClass="page-item"
                                linkClass="page-link"
                            />
                        </div>
                    ){/*}*/}

			</Fragment>
			)
	}
	</Fragment>
	);
}

export default Home