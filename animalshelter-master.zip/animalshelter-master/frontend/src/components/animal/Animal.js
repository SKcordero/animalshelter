import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { requestAnimalAdoption } from '../../actions/animalActions'
import { useDispatch, useSelector } from 'react-redux'
import { REQUEST_ADOPTION_RESET } from '../../constants/animalConstants'
import { useAlert } from 'react-alert'
const Animal = ({animal}) => {
	const dispatch = useDispatch();
	const alert = useAlert();
	// let navigate = useNavigate();
	const requestAdoptionHandler = (id) => {
        dispatch(requestAnimalAdoption(id))
    }
   const { user } = useSelector(state => state.auth);
   const { isRequested } = useSelector(state => state.requestAdoption);

   useEffect(() => {
        if (isRequested) {
            alert.success('Adoption Request Sent')
            // navigate(0)
            dispatch({
                type: REQUEST_ADOPTION_RESET
            })
        }

    }, [dispatch, alert, isRequested]);
	return  ( 
		<div className="col-sm-12 col-md-6 col-lg-3 my-3">
		<div className="container">
  <main className="grid">
    <article>
      <img alt="" src={animal.imgPath.url}/>
      <div className="textBody">
        <h3><strong>{animal.Anim_Name}</strong></h3>
        <p>{animal.Anim_Breed}</p>
        <hr/>
        <Link to={`/animal/${animal._id}`} id="view_btn" className="btn btn-block">View Animal</Link>
        {user ? (
                    user.role === 'adopter' && animal.Adoption_Status === 'Not Adopted' && (
                        <button style={{ backgroundColor: '#800000', fontFamily: 'calibri' }} onClick={() => requestAdoptionHandler(animal._id)} id="view_btn" className="btn btn-block adopt_btn">Adopt Animal</button>
                    )
                ) : <div></div> }
      </div>
    </article>
  </main>
</div>
</div>

		)

	
}
export default Animal