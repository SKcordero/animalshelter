import React, { Fragment,  useEffect, useState } from 'react'
import Loader from '../layouts/Loader'
import MetaData from '../layouts/MetaData'
import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from "react-router-dom";
import { getAnimalDetails, newCommentAnimal, clearErrors } from '../../actions/animalActions'

import { NEW_COMMENT_RESET } from '../../constants/animalConstants'
import DisplayComments from './DisplayComments'
import { useParams } from 'react-router-dom';

const AnimalDetails = ({ match }) => { 
 const dispatch = useDispatch();
    const alert = useAlert();
    let { id } = useParams();
    let navigate = useNavigate();
    const { loading, error, animal } = useSelector(state => state.animalDetails);
    const { error: commentError, isPosted } = useSelector(state => state.newComment);
    const [comment, setComment] = useState('');

    useEffect(() => {
        dispatch(getAnimalDetails(id))
        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (commentError) {
            alert.error(commentError);
            dispatch(clearErrors())
        }

        if (isPosted) {
            alert.success('Comment Posted')
            dispatch({
                type: NEW_COMMENT_RESET
            })
            navigate(`/animal/${id}`)
        }

    }, [dispatch, alert, error, id, commentError, isPosted, navigate]);

    const commentHandler = () => {
        const formData = new FormData();

        formData.set('comment', comment);
        formData.set('animalId', id);

        dispatch(newCommentAnimal(formData));
    }

    const { user } = useSelector(state => state.auth);
    // console.log(animal.Health_Status)

    let str = animal.Date_Rescued;

    if (str != null) {
     var rescueDate= str.substr(0, 10);
   }
    
    console.log(rescueDate);
     return (
        <Fragment>
            {loading ? <Loader /> : (
                <Fragment>
                    <MetaData title={animal.Anim_Name} />

                       {/* <section className="section about-section gray-bg" id="about">
            <div className="container">
                <div className="row align-items-center flex-row-reverse">
                    <div className="col-lg-6">
                        <div className="about-text go-to">
                            <h3 className="dark-color">{animal.Anim_Name}</h3>
                            <h6 className="theme-color lead">id #{animal._id}</h6>
                            <div className="row about-list">
                                <div className="col-md-6">
                                    <div className="media">
                                        <label>Type</label>
                                        <p>{animal.Anim_Type}</p>
                                    </div>
                                    <div className="media">
                                        <label>Breed</label>
                                        <p>{animal.Anim_Breed}</p>
                                    </div>
                                    <div className="media">
                                        <label>Gender</label>
                                        <p>{animal.Anim_Gender}</p>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                <div className="media">
                                        <label>Age</label>
                                        <p>{animal.Anim_Age}</p>
                                    </div>
                                    <div className="media">
                                        <label>Rescued on </label>
                                        <p>{animal.Date_Rescued}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="about-avatar">
                            {animal.imgPath &&
                                    
                                        <img src={animal.imgPath.url} alt={animal.title} />
                                    }
                        </div>
                    </div>
                </div>

                {user ? <button id="review_btn" type="button" className="btn btn-primary mt-4" data-toggle="modal" data-target="#ratingModal" >
                                Submit Your Comment
                            </button>
                                :
                                <div className="alert alert-danger mt-5" type='alert'>Login to post your comment.</div>
                            }

                <div className="row mt-2 mb-5">
                                <div className="rating w-50">
                                    <div className="modal fade" id="ratingModal" tabIndex="-1" role="dialog" aria-labelledby="ratingModalLabel" aria-hidden="true">
                                        <div className="modal-dialog" role="document">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title" id="ratingModalLabel">Write a comment</h5>
                                                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div className="modal-body">
                                                    <textarea
                                                        name="review"
                                                        id="review" className="form-control mt-3"
                                                        value={comment}
                                                        onChange={(e) => setComment(e.target.value)}
                                                        >
                                                    </textarea>
                                                    <button className="btn my-3 float-right review-btn px-4 text-white" onClick={commentHandler} data-dismiss="modal" aria-label="Close">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {animal.comments && animal.comments.length > 0 && (
                                        <DisplayComments comments={animal.comments} />
                                        )}
                                </div>
                            </div>
            </div>
        </section>*/}

        <div className="modal fade" id="ratingModal" tabIndex="-1" role="dialog" aria-labelledby="ratingModalLabel" aria-hidden="true">
                                        <div className="modal-dialog" role="document">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title" id="ratingModalLabel">Write a comment</h5>
                                                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div className="modal-body">
                                                    <textarea
                                                        name="review"
                                                        id="review" className="form-control mt-3"
                                                        value={comment}
                                                        onChange={(e) => setComment(e.target.value)}
                                                        >
                                                    </textarea>
                                                    <button className="btn my-3 float-right review-btn px-4 text-white" onClick={commentHandler} data-dismiss="modal" aria-label="Close">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>




                <div className="container mt-4 mb-4 p-3 d-flex justify-content-center">
            <div className="card p-4 col-md-4">
                <div className=" image d-flex flex-column justify-content-center "> <button className="btnProfile btn-secondary"> 

                {animal.imgPath &&
                                    
                                        <img src={animal.imgPath.url} alt={animal.title} />
                                    }
{/*                <img src="https://i.imgur.com/wvxPV9S.png" height="100" width="100" />*/}


                </button> <span className="name mt-3">{animal.Anim_Name}</span>
                    <div className="d-flex flex-row justify-content-center align-items-center gap-2"> <span className="idd1">id: {animal._id}</span> </div>
                    <hr className="new1" />
                    <div className="row">
                                <div className="col-md-6 padleft">
                                    <div >
                                        <label className="number">Type: </label>
                                        <span className="idd"> {animal.Anim_Type}</span>
                                    </div>
                                    
                                    <div >
                                        <label className="number">Age: </label>
                                        <span className="idd"> {animal.Anim_Age}</span>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                <div >
                                        <label className="number">Breed: </label>
                                        <span className="idd"> {animal.Anim_Breed}</span>
                                    </div>

                                    <div >
                                        <label className="number">Gender: </label>
                                        <span className="idd"> {animal.Anim_Gender}</span>
                                    </div>
                                </div>
                                <div className="alignInfo">
                                        <label className="number">Status: </label>
                                        <span className="idd"> {animal.Adoption_Status}</span>
                                    </div>
                            </div>
                    <div className=" px-2 rounded mt-4 date "> <span className="join">Rescued on {rescueDate}</span> </div>
                    {user ? <button id="review_btn" type="button" className="btn btn-primary mt-4" data-toggle="modal" data-target="#ratingModal" >
                                Post a Comment
                            </button>
                                :
                                <div className="alert alert-danger mt-5" type='alert'>Login to post your comment.</div>
                            }
                </div>
            </div>
            <div className="container commentSection col-md-8">
            {animal.comments && animal.comments.length > 0 && (
                                        <DisplayComments comments={animal.comments} />
                                        )}
                                    </div>

        </div>
                </Fragment>
            )}
        </Fragment>
    )
}
export default AnimalDetails