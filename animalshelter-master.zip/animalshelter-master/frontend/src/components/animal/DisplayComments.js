import React from 'react'

const DisplayComments = ({ comments }) => {
    return (
        <div className="comments ">
            <h3 className="text-center">Comments:</h3>
            <hr/>
            {comments && comments.map(comment => (
                <div key={comment._id} className="comment-card my-3">
                    <p className="review_comment text-center">" {comment.comment} "</p>
                    <p className="review_user text-right">posted by: {comment.user.name}</p>

                    <hr />
                </div>
            ))}
</div>
    )
}

export default DisplayComments