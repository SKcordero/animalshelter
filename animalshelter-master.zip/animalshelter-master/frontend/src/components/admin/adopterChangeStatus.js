import React, { Fragment, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { MDBDataTable } from 'mdbreact'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { deleteUser, getAllAdopters, changeUserStatus, clearErrors } from '../../actions/userActions'
import { DELETE_USER_RESET, CHANGE_STATUS_RESET } from '../../constants/userConstants'
import Sidebar from './Sidebar'
const ListAdopters = () => {

    const alert = useAlert();
    const dispatch = useDispatch();

    let navigate = useNavigate();

    const { loading, error, users } = useSelector(state => state.getAdopters);
    const { isChanged } = useSelector(state => state.changeStatus);
    const { isDeleted } = useSelector(state => state.user)

    useEffect(() => {
        dispatch(getAllAdopters());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (isDeleted) {
            alert.success('User deleted successfully');
            navigate('/admin/adopters');
            dispatch({ type: DELETE_USER_RESET })
        }

        if (isChanged) {
            alert.success('Status changed successfully');
            navigate('/admin/adopters');
            dispatch({ type: CHANGE_STATUS_RESET })
        }
    }, [dispatch, alert, error, navigate, isDeleted, isChanged])

    const deleteUserHandler = (id) => {
        dispatch(deleteUser(id))
    }

    const changeStatusHandler = (id) => {
        dispatch(changeUserStatus(id))
    }

    const setAdopters = () => {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc'
                },
                {
                    label: 'Name',
                    field: 'name',
                    sort: 'asc'
                },
                {
                    label: 'Gender',
                    field: 'gender',
                    sort: 'asc'
                },
                {
                    label: 'Age',
                    field: 'age',
                    sort: 'asc'
                },
                {
                    label: 'Address',
                    field: 'address',
                    sort: 'asc'
                },
                {
                    label: 'Phone',
                    field: 'phone',
                    sort: 'asc'
                },
                {
                    label: 'Status',
                    field: 'status',
                    sort: 'asc',
                },
                {
                    label: 'Actions',
                    field: 'actions',
                    sort: 'asc'
                },
            ],
            rows: []
        }

        users.forEach(user => {
            data.rows.push({
                id: user._id,
                name: user.name,
                gender: user.gender,
                age: user.age,
                address: user.address,
                phone: user.phone,
                status: user.status,
                actions: <Fragment>
                    <button className="btn btn-primary py-1 px-2" onClick={() => changeStatusHandler(user._id)}>
                        <i className="fa fa-check"></i>
                    </button>
                    <button className="btn btn-danger py-1 px-2 ml-2" onClick={() => deleteUserHandler(user._id)}>
                        <i className="fa fa-trash"></i>
                    </button>
                </Fragment>
            })
        })

        return data;
    }

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>
            <MetaData title={'Adopters'} />
             <div className="col-12 col-md-10">
                    <Fragment>
            <h1 className="my-5 text-center">Adopters List</h1>
            {loading ? <Loader /> : (

                <MDBDataTable
                    data={setAdopters()}
                    className="px-3"
                    bordered
                    striped
                    hover

                />
            )}

             </Fragment>
                </div>
        </div>
        </Fragment>
    )
}

export default ListAdopters