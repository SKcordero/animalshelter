import React, { Fragment, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { MDBDataTable } from 'mdbreact'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { getAdoptionRequests, approveAdoptionRequest, removeAdoptionRequest, clearErrors } from '../../actions/animalActions'
import { APPROVE_ADOPTION_RESET, REMOVE_REQUEST_RESET } from '../../constants/animalConstants'
import Sidebar from './Sidebar'
const ListAdoptionRequests = () => {

    const alert = useAlert();
    const dispatch = useDispatch();

    let navigate = useNavigate();

    const { loading, error, animals } = useSelector(state => state.getAdoptionRequests);
    const { isApproved } = useSelector(state => state.approveAdoption);
    const { isDenied } = useSelector(state => state.removeRequest);

    useEffect(() => {
        dispatch(getAdoptionRequests());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (isApproved) {
            alert.success('Animal Adopted Successfully');
            navigate('/animals/requests');
            dispatch({ type: APPROVE_ADOPTION_RESET })
        }

        if (isDenied) {
            alert.success('Request Removed Successfully');
            navigate('/animals/requests');
            dispatch({ type: REMOVE_REQUEST_RESET })
        }

    }, [dispatch, alert, error, navigate, isApproved, isDenied])

    const approveAdoptionHandler = (id) => {
        dispatch(approveAdoptionRequest(id))
    }

    const removeRequestHandler = (id) => {
        dispatch(removeAdoptionRequest(id))
    }

    const setAdoptionRequests = () => {
        const data = {
            columns: [
                {
                    label: 'Animal ID',
                    field: 'id',
                    sort: 'asc'
                },
                {
                    label: 'Name',
                    field: 'Anim_Name',
                    sort: 'asc'
                },
                {
                    label: 'Category',
                    field: 'Anim_Type',
                    sort: 'asc'
                },
                {
                    label: 'Breed',
                    field: 'Anim_Breed',
                    sort: 'asc'
                },
                {
                    label: 'Status',
                    field: 'Health_Status',
                    sort: 'asc'
                },
                {
                    label: 'Adopter',
                    field: 'adoptionuser',
                    sort: 'asc'
                },
                {
                    label: 'Requested on',
                    field: 'adoptionrequested_at',
                    sort: 'asc'
                },
                {
                    label: 'Actions',
                    field: 'actions',
                    sort: 'asc'
                },
            ],
            rows: []
        }

        animals.forEach(animal => {
            data.rows.push({
                id: animal._id,
                Anim_Name: animal.Anim_Name,
                Anim_Type: animal.Anim_Type,
                Anim_Breed: animal.Anim_Breed,
                Health_Status: animal.Health_Status,
                adoptionuser: animal.adoption.user.name,
                adoptionrequested_at: animal.adoption.requested_at,
                actions: <Fragment>
                    <button  onClick={() => approveAdoptionHandler(animal._id)} className="btn btn-primary py-1 px-2">
                            <i className="fa fa-check"></i>
                        </button>
                    <button className="btn btn-danger py-1 px-2 ml-2" onClick={() => removeRequestHandler(animal._id)}>
                        <i className="fa fa-trash"></i>
                    </button>
                </Fragment>
            })
        })

        return data;
    }

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>
            <MetaData title={'Adoption Requests'} />
             <div className="col-12 col-md-10">
                    <Fragment>
            <h1 className="my-5 text-center">List of Adoption Requests</h1>
            {loading ? <Loader /> : (

                <MDBDataTable
                    data={setAdoptionRequests()}
                    className="px-3"
                    bordered
                    striped
                    hover

                />
            )}

             </Fragment>
                </div>
        </div>
        </Fragment>
    )
}

export default ListAdoptionRequests