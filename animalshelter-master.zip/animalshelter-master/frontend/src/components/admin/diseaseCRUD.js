import React, { Fragment, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { MDBDataTable } from 'mdbreact'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { allDiseases, deleteDisease, clearErrors } from '../../actions/diseaseActions'
import { DELETE_DISEASE_RESET } from '../../constants/diseaseConstants'
import Sidebar from './Sidebar'
const ListDiseases = () => {

    const alert = useAlert();
    const dispatch = useDispatch();

    let navigate = useNavigate();

    const { loading, error, diseases } = useSelector(state => state.getDiseases);
    const { isDeleted } = useSelector(state => state.disease)

    useEffect(() => {
        dispatch(allDiseases());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (isDeleted) {
            alert.success('Disease deleted successfully');
            navigate('/diseases');
            dispatch({ type: DELETE_DISEASE_RESET })
        }
    }, [dispatch, alert, error, navigate, isDeleted])

    const deleteDiseaseHandler = (id) => {
        dispatch(deleteDisease(id))
    }

    const setDiseases = () => {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc'
                },
                {
                    label: 'Name',
                    field: 'Dis_Name',
                    sort: 'asc'
                },
                {
                    label: 'Description',
                    field: 'Dis_Info',
                    sort: 'asc',
                    autoWidth: true
                },
                {
                    label: 'Actions',
                    field: 'actions',
                    sort: 'asc'
                },
            ],
            rows: []
        }

        diseases.forEach(disease => {
            data.rows.push({
                id: disease._id,
                Dis_Name: disease.Dis_Name,
                Dis_Info: disease.Dis_Info,
                actions: <Fragment>
                    <Link to={`/disease/${disease._id}`} className="btn btn-primary py-1 px-2">
                        <i className="fa fa-pen"></i>
                    </Link>
                    <button className="btn btn-danger py-1 px-2 ml-2" onClick={() => deleteDiseaseHandler(disease._id)}>
                        <i className="fa fa-trash"></i>
                    </button>
                </Fragment>
            })
        })

        return data;
    }

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>
            <MetaData title={'Diseases'} />
             <div className="col-12 col-md-10">
                    <Fragment>
            <h1 className="my-5 text-center">Diseases List</h1>
            {loading ? <Loader /> : (

                <MDBDataTable
                    data={setDiseases()}
                    className="px-3"
                    bordered
                    striped
                    hover

                />
            )}
            <div className="col-12 col-md-2 col-sm-4 float-left">
            <Link to={`/disease/new`} id="view_btn" className="btn btn-block"><i className="fa fa-plus"></i> Add Disease</Link>
            </div>
             </Fragment>
                </div>
        </div>
        </Fragment>
    )
}

export default ListDiseases