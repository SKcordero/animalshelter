import React, { Fragment, useState, useEffect } from 'react'

import MetaData from '../layouts/MetaData'
import Sidebar from './Sidebar'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { useParams, useNavigate } from 'react-router-dom';
import { updateDisease, getDiseaseDetails, clearErrors } from '../../actions/diseaseActions'
import { UPDATE_DISEASE_RESET } from '../../constants/diseaseConstants'

const UpdateDisease = () => {

    const [name, setName] = useState('');
    const [info, setInfo] = useState('');

    const alert = useAlert();
    const dispatch = useDispatch();

    const { error, disease } = useSelector(state => state.diseaseDetails)
    const { loading, error: updateError, isUpdated } = useSelector(state => state.disease);

    let { id } = useParams();
    let navigate = useNavigate();
   
    useEffect(() => {

        if (disease && disease._id !== id) {
            dispatch(getDiseaseDetails(id));
        } else {
            setName(disease.Dis_Name);
            setInfo(disease.Dis_Info);
        }

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (updateError) {
            alert.error(updateError);
            dispatch(clearErrors())
        }


        if (isUpdated) {
            navigate('/diseases');
            alert.success('Disease updated successfully');
            dispatch({ type: UPDATE_DISEASE_RESET })
        }

    }, [dispatch, alert, error, isUpdated, navigate, updateError, disease, id])


    const submitHandler = (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.set('Dis_Name', name);
        formData.set('Dis_Info', info);

        dispatch(updateDisease(disease._id, formData))
    }

    // const onChange = e => {

    //     const files = Array.from(e.target.files)

    //     setImagesPreview([]);
    //     setImages([])
    //     setOldImages([])

    //     files.forEach(file => {
    //         const reader = new FileReader();

    //         reader.onload = () => {
    //             if (reader.readyState === 2) {
    //                 setImagesPreview(oldArray => [...oldArray, reader.result])
    //                 setImages(oldArray => [...oldArray, reader.result])
    //             }
    //         }

    //         reader.readAsDataURL(file)
    //     })
    // }


    return (
        <Fragment>
            <MetaData title={'Update Disease'} />
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>

                <div className="col-12 col-md-10">
                    <Fragment>
                        <div className="wrapper my-5">
                            <form className="shadow-lg" onSubmit={submitHandler} encType='multipart/form-data'>
                                <h1 className="mb-4">Update Disease</h1>

                                <div className="form-group">
                                    <label htmlFor="name_field">Name</label>
                                    <input
                                        type="text"
                                        id="name_field"
                                        className="form-control"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                    />
                                </div>

                                <div className="form-group">
                                    <label htmlFor="info_field">Description</label>
                                    <input
                                        type="text"
                                        id="info_field"
                                        className="form-control"
                                        value={info}
                                        onChange={(e) => setInfo(e.target.value)}
                                    />
                                </div>

                                <button
                                    id="login_button"
                                    type="submit"
                                    className="btn btn-block py-3"
                                    disabled={loading ? true : false}
                                >
                                    UPDATE
                            </button>

                            </form>
                        </div>
                    </Fragment>
                </div>
            </div>

        </Fragment>
    )
}

export default UpdateDisease