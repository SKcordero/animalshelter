import React, { Fragment, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { MDBDataTable } from 'mdbreact'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { allAnimals, deleteAnimal, clearErrors } from '../../actions/animalActions'
import { DELETE_ANIMALS_RESET } from '../../constants/animalConstants'
import Sidebar from './Sidebar'
const ListAnimals = () => {

    const alert = useAlert();
    const dispatch = useDispatch();

    let navigate = useNavigate();

    const { loading, error, animals } = useSelector(state => state.allAnimals);
    const { isDeleted } = useSelector(state => state.newAnimals)

    useEffect(() => {
        dispatch(allAnimals());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (isDeleted) {
            alert.success('Animal deleted successfully');
            navigate('/animals');
            dispatch({ type: DELETE_ANIMALS_RESET })
        }
    }, [dispatch, alert, error, navigate, isDeleted])

    const deleteAnimalHandler = (id) => {
        dispatch(deleteAnimal(id))
    }

    const setAnimals = () => {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc'
                },
                {
                    label: 'Name',
                    field: 'Anim_Name',
                    sort: 'asc'
                },
                {
                    label: 'Category',
                    field: 'Anim_Type',
                    sort: 'asc'
                },
                {
                    label: 'Breed',
                    field: 'Anim_Breed',
                    sort: 'asc'
                },
                {
                    label: 'Gender',
                    field: 'Anim_Gender',
                    sort: 'asc'
                },
                {
                    label: 'Age',
                    field: 'Anim_Age',
                    sort: 'asc'
                },
                {
                    label: 'Health Status',
                    field: 'Health_Status',
                    sort: 'asc',
                },
                {
                    label: 'Adoption Status',
                    field: 'Adoption_Status',
                    sort: 'asc',
                },
                {
                    label: 'Rescued on',
                    field: 'Date_Rescued',
                    sort: 'asc',
                },
                {
                    label: 'Actions',
                    field: 'actions',
                    sort: 'asc'
                },
            ],
            rows: []
        }

        animals.forEach(animal => {
            data.rows.push({
                id: animal._id,
                Anim_Name: animal.Anim_Name,
                Anim_Type: animal.Anim_Type,
                Anim_Breed: animal.Anim_Breed,
                Anim_Gender: animal.Anim_Gender,
                Anim_Age: animal.Anim_Age,
                Health_Status: animal.Health_Status,
                Adoption_Status: animal.Adoption_Status,
                Date_Rescued: animal.Date_Rescued,
                actions: <Fragment>
                    <Link to={`/animalUpdate/${animal._id}`} className="btn btn-primary py-1 px-2">
                        <i className="fa fa-pen"></i>
                    </Link>
                    <button className="btn btn-danger py-1 px-2 ml-2" onClick={() => deleteAnimalHandler(animal._id)}>
                        <i className="fa fa-trash"></i>
                    </button>
                </Fragment>
            })
        })

        return data;
    }

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>
            <MetaData title={'Animals'} />
             <div className="col-12 col-md-10">
                    <Fragment>
            <h1 className="my-5 text-center">Animals List</h1>
            {loading ? <Loader /> : (

                <MDBDataTable
                    data={setAnimals()}
                    className="px-3"
                    bordered
                    striped
                    hover

                />
            )}
            <div className="col-12 col-md-2 col-sm-4 float-left">
            <Link to='/animal/new' id="view_btn" className="btn btn-block"> <i className="fa fa-plus"></i> Add Animal</Link>
            </div>
             </Fragment>
                </div>
        </div>
        </Fragment>
    )
}

export default ListAnimals