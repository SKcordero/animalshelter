import React, { Fragment, useEffect } from 'react'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'
import Sidebar from './Sidebar'
import RescuedCharts from './RescuedChart'
import AdoptedCharts from './AdoptedChart'

import { useDispatch } from 'react-redux'

import { allDiseases } from '../../actions/diseaseActions'

const Dashboard = () => {

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(allDiseases())
    }, [dispatch])

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>

                <div className="col-12 col-md-10">
                    <h1 className="my-4 text-center">Dashboard</h1>

                    {false ? <Loader /> : (
                        <Fragment>
                            <MetaData title={'Admin Dashboard'} />
                            <div className="row pr-4">
                               <RescuedCharts/>
                               <AdoptedCharts/>
                            </div>
                        </Fragment>
                    )}

                </div>
            </div>

        </Fragment >
    )
}

export default Dashboard