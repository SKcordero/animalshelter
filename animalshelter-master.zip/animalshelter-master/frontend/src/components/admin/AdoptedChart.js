import React, { Fragment, useState, useRef, useEffect } from 'react'
import dateFormat from 'dateformat';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
// import faker from 'faker';

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { adoptedCharts, clearErrors } from '../../actions/animalActions'
import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

const AdoptedCharts  = () => {
    const alert = useAlert();
    const dispatch = useDispatch();

    ChartJS.register(
        CategoryScale,
        LinearScale,
        BarElement,
        Title,
        Tooltip,
        Legend
    );
    const { loading, error, animals } = useSelector(state => state.adoptedChart);

    useEffect(() => {
        dispatch(adoptedCharts());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

    }, [dispatch, alert, error])

    const config = {
        indexAxis: 'x',
        elements: {
            bar: {
                borderWidth: 2,
            },
        },
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Adopted animal per month',
            },
        },
    };
    console.log(animals);
    // const groupstest = animals.reduce(
    //     (groupstest, adopted_animal) => {
    //         const adopteddate = dateFormat(adopted_animal.adoption.date_adopted.split('T')[0], "mmmm")
    //         if (!groupstest[adopteddate]) {
    //             groupstest[adopteddate]=[]
    //         }
    //         groupstest[adopteddate].push(adopted_animal);
    //         return groupstest;
    //     }, {}
    // )

    const groups = animals.reduce(
        (groups, adopted_animal) => {
            const adopteddate = adopted_animal.adoption.date_adopted;
            if (!groups[adopteddate]) {
                groups[adopteddate]=[]
            }
            groups[adopteddate].push(adopted_animal);
            return groups;
        }, {}
    )

    const adoptedAnimalDate = Object.keys(groups)

    const animalDateMonth = adoptedAnimalDate.reduce(

        (animalDateMonth, adopted_animal) => {
            const adopteddate = dateFormat(adopted_animal, "mmmm")
            if (!animalDateMonth[adopteddate]) {
                animalDateMonth[adopteddate]=[]
            }
            animalDateMonth[adopteddate].push(adopted_animal);
            return animalDateMonth;
        }, {}
    )

    const animalDateGroup  = Object.keys(animalDateMonth)

    const animalCount = Object.values(animalDateMonth)
    const animalCountLength = Object.values(animalCount).map((animal)=> {
        return animal.length
    })

    const [DateLabels, setRescueDates] = useState(animalDateGroup);
    const [DataRescue, setRescueDataPoints] = useState(animalCountLength);

    const [rescuedStart, setRescuedStart] = useState('2022-01-01');
    const [rescuedEnd, setRescuedEnd] = useState('2022-12-31');

    const StartDate = useRef();
    const EndDate = useRef();
    const arrGroups = Object.entries(groups);

    function FromData() {

        let valueStart = StartDate.current.value;
        setRescuedStart(valueStart);
        let valueEnd = rescuedEnd;

        const newgroups = arrGroups.filter(
            (obj) =>{
                return  obj >= valueStart &&  obj <= valueEnd
            }
        )

        const newData = Object.fromEntries(newgroups);

        const animalDateGroup  = Object.keys(newData)

        const newAnimalDateGroup = animalDateGroup.reduce((newAnimalDateGroup, adopted_animal )=>{
            const adopteddate = dateFormat(adopted_animal, "mmmm")
            if (!newAnimalDateGroup[adopteddate]) {
                newAnimalDateGroup[adopteddate]=[]
            }
            newAnimalDateGroup[adopteddate].push(adopted_animal);

            return newAnimalDateGroup;
        }, {});

        const uniqueDates = Object.keys(newAnimalDateGroup);
        setRescueDates(uniqueDates);

        const newAnimalCount = Object.values(newAnimalDateGroup)
        const newAnimalCountLength = Object.values(newAnimalCount).map((animal)=> {
            return animal.length
        })
        setRescueDataPoints(newAnimalCountLength);

    };

    function ToData() {

        let valueEnd = EndDate.current.value;
        setRescuedEnd(valueEnd);
        let valueStart = rescuedStart;
        const newgroups = arrGroups.filter(
            (obj) =>{
                return  obj >= valueStart &&  obj <= valueEnd
            }
        )

        const newData = Object.fromEntries(newgroups);

        const animalDateGroup  = Object.keys(newData)

        const newAnimalDateGroup = animalDateGroup.reduce((newAnimalDateGroup, adopted_animal )=>{
            const adopteddate = dateFormat(adopted_animal, "mmmm")
            if (!newAnimalDateGroup[adopteddate]) {
                newAnimalDateGroup[adopteddate]=[]
            }
            newAnimalDateGroup[adopteddate].push(adopted_animal);

            return newAnimalDateGroup;
        }, {});

        const uniqueDates = Object.keys(newAnimalDateGroup);
        setRescueDates(uniqueDates);

        const newAnimalCount = Object.values(newAnimalDateGroup)
        const newAnimalCountLength = Object.values(newAnimalCount).map((animal)=> {
            return animal.length
        })
        setRescueDataPoints(newAnimalCountLength);

    };

    const dataOptions = [
            {
                label: 'Animal',
                backgroundColor: ['#CC9544',
                                  '#603601',
                                  '#361500',
                                  '#FF7700',
                                  '#E04D01',
                                  '#2A2550',
                                  '#251D3A'],
                borderColor: '#000000',
                borderWidth: 1,
                data: DataRescue
            }
        ];

    const chartData = {
        labels: DateLabels,
        datasets: dataOptions
            }
    
    return (
        <Fragment>
        <MetaData title={'Dashboard'} />
        {loading ? <Loader /> : (
            <div className="col-md-6">
                <h3 className="my-4 text-center">Adopted Animal</h3>
                <Bar
                    data={chartData}
                    options={config}
                />
                <div className="form-group text-center">
                    <label >Start:</label>
                    <input type="date" ref={StartDate} onChange={FromData}/>
                    <label >End:</label>
                    <input type="date" ref={EndDate} onChange={ToData}/>
                </div>
            </div>
        )}
        </Fragment>
    )
}
export default AdoptedCharts
