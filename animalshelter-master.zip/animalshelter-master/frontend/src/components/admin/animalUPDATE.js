import React, { Fragment, useState, useEffect } from 'react'

import MetaData from '../layouts/MetaData'
import Sidebar from './Sidebar'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { useParams, useNavigate } from 'react-router-dom';
import { updateAnimal, getAnimalDetails, clearErrors } from '../../actions/animalActions'
import { UPDATE_ANIMAL_RESET } from '../../constants/animalConstants'

// import { allDiseases } from '../../actions/diseaseActions'
// import { allInjuries } from '../../actions/injuryActions'
const UpdateAnimal = () => {

    // const [setUser] = useState('');
    const [name, setName] = useState('')
    const [type, setType] = useState('')
    const [breed, setBreed] = useState('')
    const [gender, setGender] = useState('')
    const [age, setAge] = useState('')
    const [imgPath, setimgPath] = useState('')
    // const [getdiseases, setDiseases] = useState([])
    // const [getinjuries, setInjuries] = useState([])

    const [avatarPreview, setAvatarPreview] = useState('')

    const alert = useAlert();
    const dispatch = useDispatch();

    const { loading, error: updateError, isUpdated } = useSelector(state => state.newAnimals);
    const { error, animal } = useSelector(state => state.animalDetails)
    // const { diseases } = useSelector(state => state.getDiseases);
    // const { injuries } = useSelector(state => state.getInjuries);

    let { id } = useParams();
    let navigate = useNavigate();
   console.log(animal)
    useEffect(() => {
        // dispatch(allDiseases());
        // dispatch(allInjuries());

        if (animal && animal._id !== id) {
            dispatch(getAnimalDetails(id));
        } else {
            setName(animal.Anim_Name);
            setType(animal.Anim_Type);
            setBreed(animal.Anim_Breed);
            setGender(animal.Anim_Gender);
            setAge(animal.Anim_Age);
            setAvatarPreview(animal.imgPath.url);
        }

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (updateError) {
            alert.error(updateError);
            dispatch(clearErrors())
        }


        if (isUpdated) {
            navigate('/animals');
            alert.success('Animal updated successfully');
            dispatch({ type: UPDATE_ANIMAL_RESET })
        }

    }, [dispatch, alert, error, isUpdated, navigate, updateError, animal, id])


    const submitHandler = (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.set('Anim_Name', name);
        formData.set('Anim_Type', type);
        formData.set('Anim_Breed', breed);
        formData.set('Anim_Gender', gender);
        formData.set('Anim_Age', age);
        formData.set('imgPath', imgPath);

        // getdiseases.forEach(getdisease => 
        //     formData.append('Anim_Diseases', getdisease)
        //     )
        // getinjuries.forEach(getinjury => 
        //     formData.append('Anim_Injuries', getinjury)
        //     )

        dispatch(updateAnimal(animal._id, formData))
    }

    const onChange = e => {
         if (e.target.name === 'avatar') {
            const reader = new FileReader();

            reader.onload = () => {
                if (reader.readyState === 2) {
                    setAvatarPreview(reader.result)
                    setimgPath(reader.result)
                }
            }
            reader.readAsDataURL(e.target.files[0])
    }
    }


    return (
        <Fragment>
            <MetaData title={'Update Animal'} />
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>

                <div className="col-12 col-md-10">
                    <Fragment>
                        <div className="wrapper my-5">
                            <form className="shadow-lg" onSubmit={submitHandler} encType='multipart/form-data'>
                                <h1 className="mb-4">Update Animal</h1>

                                <div className="form-group">
                            <label htmlFor="name_field">Name</label>
                            <input
                                type="name"
                                id="name_field"
                                className="form-control"
                                name='name'
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                            />
                        </div>

                        <div className="form-group">
                                    <label htmlFor="type_field">Type</label>
                                    <select
                                        id="type_field"
                                        className="form-control"
                                        name='type'
                                        value={type}
                                        onChange={(e) => setType(e.target.value)}
                                    >
                                        {/*<option value="" disabled hidden>--Select type--</option>*/}
                                        <option value="Cat">Cat</option>
                                        <option value="Dog">Dog</option>
                                    </select>
                                </div>

                        <div className="form-group">
                            <label htmlFor="name_field">Breed</label>
                            <input
                                type="name"
                                id="name_field"
                                className="form-control"
                                name='breed'
                                value={breed}
                                onChange={(e) => setBreed(e.target.value)}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="gender_field">Gender</label>
                            {/*<input
                                type="gender"
                                id="gender_field"
                                className="form-control"
                                name='gender'
                                value={gender}
                                onChange={onChange}
                            />*/}
                            <select 
                                type="gender" 
                                id="gender_field"
                                className="form-control"
                                name='gender'
                                value={gender}
                                onChange={(e) => setGender(e.target.value)}
                                placeholder="Select Gender">
                                <option value="" disabled hidden>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label htmlFor="age_field">Age</label>
                            <input
                                type="number"
                                id="age_field"
                                className="form-control"
                                name='age'
                                value={age}
                                onChange={(e) => setAge(e.target.value)}
                            />
                        </div>

                        {/*<div className="row">
                                    <div className="col">
                                        <div className="form-group">
                                            <label htmlFor="disease_field">Diseases:</label>
                                            {diseases.map(disease => (
                                                <div key={disease._id}>
                                                    <input
                                                    type="checkbox"
                                                    id="checkbox"
                                                    name='checkbox'
                                                    value={disease._id}
                                                    onChange={e => setDiseases([...getdiseases, disease._id])}
                                                />
                                                <label className="">{disease.Dis_Name}</label>
                                                </div>
                                                ))}
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="form-group">
                                            <label htmlFor="injury_field">Injuries:</label>
                                            {injuries.map(injury => (
                                                <div key={injury._id}>
                                                    <input
                                                    type="checkbox"
                                                    id="checkbox"
                                                    name='checkbox'
                                                    value={injury._id}
                                                    onChange={e => setInjuries([...getinjuries, injury._id])}
                                                />
                                                <label className="">{injury.Inj_Name}</label>
                                                </div>
                                                ))}
                                        </div>
                                    </div>
                                </div>*/}

                        <div className='form-group'>
                            <label htmlFor='avatar_upload'>Image</label>
                            <div className='d-flex align-items-center'>
                                <div>
                                    <figure className='avatar mr-3 item-rtl'>
                                        <img
                                            src={avatarPreview}
                                            className='rounded-circle'
                                            alt='Avatar Preview'
                                        />
                                    </figure>
                                </div>
                                <div className='custom-file'>
                                    <input
                                        type='file'
                                        name='avatar'
                                        className='custom-file-input'
                                        id='customFile'
                                        accept="images/*"
                                        onChange={onChange}
                                    />
                                    <label className='custom-file-label' htmlFor='customFile'>
                                        Choose Image
                                    </label>
                                </div>
                            </div>
                        </div>

                                <button
                                    id="login_button"
                                    type="submit"
                                    className="btn btn-block py-3"
                                    disabled={loading ? true : false}
                                >
                                    UPDATE
                            </button>

                            </form>
                        </div>
                    </Fragment>
                </div>
            </div>

        </Fragment>
    )
}

export default UpdateAnimal