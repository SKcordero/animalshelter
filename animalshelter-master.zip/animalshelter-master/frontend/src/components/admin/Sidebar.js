import React from 'react'
import { Link } from 'react-router-dom'

const Sidebar = () => {
    return (
        <div className="sidebar-wrapper">
            <nav id="sidebar">
                <ul className="list-unstyled components">
                    <li>
                        <Link to="/dashboard"><i className="fa fa-chart-line"></i> Dashboard</Link>
                    </li>
                    <li>
                        <Link to="/animals"><i className="fa fa-cat"></i> Animals</Link>
                    </li>
                    <li>
                        <Link to="/admin/users"><i className="fa fa-users"></i> Users</Link>
                    </li>
                    <li>
                        <Link to="/admin/adopters"><i className="fa fa-user"></i> Adopters</Link>
                    </li>
                    <li>
                        <Link to="/diseases"><i className="fa fa-virus"></i> Diseases</Link>
                    </li>
                    <li>
                        <Link to="/injuries"><i className="fa fa-crutch"></i> Injuries</Link>
                    </li>
                    <li>
                        <Link to="/animals/sick"><i className="fa fa-syringe"></i> Treatment</Link>
                    </li>
                    <li>
                        <Link to="/animals/requests"><i className="fa fa-bell"></i> Requests</Link>
                    </li>

{/*                    <li>
                        <Link to="/admin/users"><i className="fa fa-users"></i> Users</Link>
                    </li>

                    <li>
                        <Link to="/admin/reviews"><i className="fa fa-star"></i> Reviews</Link>
                    </li>*/}

                </ul>
            </nav>
        </div>
    )
}

export default Sidebar