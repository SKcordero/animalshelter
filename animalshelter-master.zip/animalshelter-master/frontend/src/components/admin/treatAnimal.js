import React, { Fragment, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { MDBDataTable } from 'mdbreact'

import MetaData from '../layouts/MetaData'
import Loader from '../layouts/Loader'

import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { getSickAnimals, cureAnimal, clearErrors } from '../../actions/animalActions'
import { CURE_ANIMALS_RESET } from '../../constants/animalConstants'
import Sidebar from './Sidebar'
const ListSickAnimals = () => {

    const alert = useAlert();
    const dispatch = useDispatch();

    let navigate = useNavigate();

    const { loading, error, animals } = useSelector(state => state.getSickAnimals);
    const { isCured } = useSelector(state => state.cureAnimal);

    useEffect(() => {
        dispatch(getSickAnimals());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

        if (isCured) {
            alert.success('Animal treated successfully');
            navigate('/');
            dispatch({ type: CURE_ANIMALS_RESET })
        }

    }, [dispatch, alert, error, navigate, isCured])

    const cureAnimalHandler = (id) => {
        dispatch(cureAnimal(id))
    }

    const setSickAnimals = () => {
        const data = {
            columns: [
                {
                    label: 'ID',
                    field: 'id',
                    sort: 'asc'
                },
                {
                    label: 'Name',
                    field: 'Anim_Name',
                    sort: 'asc'
                },
                {
                    label: 'Category',
                    field: 'Anim_Type',
                    sort: 'asc'
                },
                {
                    label: 'Breed',
                    field: 'Anim_Breed',
                    sort: 'asc'
                },
                {
                    label: 'Gender',
                    field: 'Anim_Gender',
                    sort: 'asc'
                },
                {
                    label: 'Age',
                    field: 'Anim_Age',
                    sort: 'asc'
                },
                {
                    label: 'Status',
                    field: 'Health_Status',
                    sort: 'asc'
                },
                {
                    label: 'Actions',
                    field: 'actions',
                    sort: 'asc'
                },
            ],
            rows: []
        }

        animals.forEach(animal => {
            data.rows.push({
                id: animal._id,
                Anim_Name: animal.Anim_Name,
                Anim_Type: animal.Anim_Type,
                Anim_Breed: animal.Anim_Breed,
                Anim_Gender: animal.Anim_Gender,
                Anim_Age: animal.Anim_Age,
                Health_Status: animal.Health_Status,
                actions: <Fragment>
                    <button className="btn btn-danger py-1 px-2 ml-2" onClick={() => cureAnimalHandler(animal._id)}>
                        <i className="fa fa-syringe"></i>
                    </button>
                </Fragment>
            })
        })

        return data;
    }

    return (
        <Fragment>
            <div className="row">
                <div className="col-12 col-md-2">
                    <Sidebar />
                </div>
            <MetaData title={'Sick Animals'} />
             <div className="col-12 col-md-10">
                    <Fragment>
            <h1 className="my-5 text-center">List of Sick Animals</h1>
            {loading ? <Loader /> : (

                <MDBDataTable
                    data={setSickAnimals()}
                    className="px-3"
                    bordered
                    striped
                    hover

                />
            )}

             </Fragment>
                </div>
        </div>
        </Fragment>
    )
}

export default ListSickAnimals