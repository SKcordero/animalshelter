import React, { Fragment, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { getAdoptedAnimals } from '../../actions/animalActions'
import { useDispatch, useSelector } from 'react-redux'
import { useAlert } from 'react-alert'
import { logout, login } from '../../actions/userActions'
import { useParams } from 'react-router-dom';
import Search from './Search'
import '../../App.css'

const Header = () => {
    const alert = useAlert();
    const dispatch = useDispatch();
    let { id } = useParams();

    const { user, loading } = useSelector(state => state.auth)
    const { error } = useSelector(state => state.getAdoptedAnimals)
    // const { cartItems } = useSelector(state => state.cart)

    const logoutHandler = () => {
        dispatch(logout());
        alert.success('Logged out successfully.')
    }

    const loginHandler = () => {
        dispatch(login());
        // alert.success('Logged in successfully.')
    }

    useEffect( () => { 
        dispatch(getAdoptedAnimals(id))
        if(error){
            alert.error('error')
        }

    }, [dispatch, alert, error, id] );

    return (
        <Fragment>
          <nav className="navbar row">
       <div className="col-12 col-md-3">
         <div className="navbar-brand">
            <Link to="/" style={{ textDecoration: 'none' }} onClick={() => {window.location.href="/"}}>
           <span><i className="fas fa-paw"/> Animal Shelter</span>
           </Link>
         </div>
       </div>

       <div className="col-12 col-md-6 mt-2 mt-md-0">
          {/*Search*/}
          {/*<div className="col-12 col-md-6 mt-2 mt-md-0">*/}
         {/* <Route render={({ history }) => <Search history={history} />} />*/}
          <Search />

          {/*</div>*/}

       </div>

       <div className="col-12 col-md-3 mt-4 mt-md-0 text-center">
                    {user ? (
                        <div className="ml-4 dropdown d-inline">
                            <Link to="#!" className="btn dropdown-toggle text-white mr-4" type="button" id="dropDownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                <figure className="avatar avatar-nav">
                                    <img
                                        src={user.avatar && user.avatar.url}
                                        alt={user && user.name}
                                        className="rounded-circle"
                                    />
                                </figure>
                                <span>{user && user.name}</span>
                            </Link>

                            <div className="dropdown-menu" aria-labelledby="dropDownMenuButton">

                                {user && user.role === 'admin' && (
                                    <Link className="dropdown-item" to="/dashboard">Dashboard</Link>
                                )}
                                <Link className="dropdown-item" to="/me">Profile</Link>

                                {user && user.role === 'adopter' && (
                                        <Link className="dropdown-item" to="/me/adopted">Adopted</Link>
                                )}

                                <Link className="dropdown-item text-danger" to="/" onClick={logoutHandler}>Logout
                                 {/*<Link className="dropdown-item text-danger" to="/" >
                                    Logout*/}
                                </Link>

                            </div>


                        </div>

                    ) : !loading && 

                    <Link to="/login" id="login_btn" onClick={loginHandler} className="btn ml-4">Login</Link>}


                </div>
            </nav>
        </Fragment>
    )
}
export default Header