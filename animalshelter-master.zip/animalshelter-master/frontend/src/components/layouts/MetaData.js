import React from 'react'
import { Helmet } from 'react-helmet'
const MetaData = ({ title }) => {
    return (
        <Helmet>
            <title>{`${title} - CORDERO | BSIT-NS-3A`}</title>
        </Helmet>
    )
}

export default MetaData