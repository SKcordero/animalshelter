import React, { Fragment, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import Loader from '../layouts/Loader'
import MetaData from '../layouts/MetaData'
import { useAlert } from 'react-alert'
import Animal from '../animal/Animal'
import { getAdoptedAnimals, clearErrors } from '../../actions/animalActions'

const AdoptedAnimals = () => {

    const alert = useAlert();
    const dispatch = useDispatch();
    // let navigate = useNavigate();

    const { loading, error, animals } = useSelector(state => state.getAdoptedAnimals);

    useEffect(() => {
        dispatch(getAdoptedAnimals());

        if (error) {
            alert.error(error);
            dispatch(clearErrors())
        }

    }, [dispatch, alert, error])

    return (
        <Fragment>
            {loading ? <Loader /> : (
                <Fragment>
                    <MetaData title={'Adopted Animals'} />
                    <div className="adopter">
                        <h1 align="center">Adopted Animals</h1>
                    </div>
                    <section  id="adoptedanimals" className="Details container mt-5">
                        <div className="row">
                            {animals && animals.map(animal => (
                                <Animal key={animal._id} animal={animal} col={4} />
                            ))}
                        </div>
                    </section>
                </Fragment>
            )}
        </Fragment>
    )
}

export default AdoptedAnimals