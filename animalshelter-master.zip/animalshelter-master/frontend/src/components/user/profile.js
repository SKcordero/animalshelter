import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

import Loader from '../layouts/Loader'
import MetaData from '../layouts/MetaData'

const Profile = () => {

    const { user, loading } = useSelector(state => state.auth)

    return (
        <Fragment>
            {loading ? <Loader /> : (
                <Fragment>
                    <MetaData title={'Your Profile'} />

                    <h2 className="mt-5 ml-5 text-center">My Profile</h2>
                    <div className="container userProfile">
                    <div className="row justify-content-around user-info container" >
                        <div className="col-12 col-md-4 userImagebtns" align='center'>
                            <figure className='avatar avatar-profile'>
                                <img className="rounded-circle img-fluid" src={user.avatar.url} alt={user.name} />
                            </figure>
                            <Link to="/me/update" className="editProfilebtn btn btn-block mt-3">
                                Edit Profile
                            </Link>
                            <Link to="/password/update" className="btn changePassbtn btn-block mt-3">
                                Change Password
                            </Link>
                        </div>

                        <div className="col-12 col-md-4">
                            <h4>Full Name</h4>
                            <p>{user.name}</p>

                            <h4>Gender</h4>
                            <p>{user.gender}</p>

                            <h4>Age</h4>
                            <p>{user.age}</p>

                            <h4>Address</h4>
                            <p>{user.address}</p>

                        </div>
                        <div className="col-12 col-md-4">
                            <h4>Phone no.</h4>
                            <p>{user.phone}</p>

                            <h4>Email Address</h4>
                            <p>{user.email}</p>

                            <h4>Joined On</h4>
                            <p>{String(user.createdAt).substring(0, 10)}</p>
                        </div>
                    </div>
                    </div>
                </Fragment>
            )}
        </Fragment>
    )
}

export default Profile
